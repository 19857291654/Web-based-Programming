const { defineConfig } = require('@vue/cli-service')

module.exports = defineConfig({
  publicPath: process.env.NODE_ENV === "production" ? "http://html-static-resource.oss-cn-hangzhou.aliyuncs.com/ai-edu-home-fe" : "/",
  transpileDependencies: true
})
