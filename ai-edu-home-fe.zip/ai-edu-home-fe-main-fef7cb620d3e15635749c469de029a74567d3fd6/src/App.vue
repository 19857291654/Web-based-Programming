<template>
  <router-view />
</template>

<style lang="less">
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
}

body {
  border: 0;
  padding: 0;
  margin: 0;
}

@codeColor: #fdfcfb;
@oneDark: #282c34;

:root {
  --top-bottom-background-color: #fdfcfb;
  --compiler-background-color: #dae3ea;
  --codeEdit-background-color: #eee;
  --top-button-background-color: @codeColor;
  --cm-editor-background-color: @codeColor;
  --separator-background-color: #e1e0e0;
  --text-background-color: @codeColor;
  --default-border: 1px solid #ccc;
  --text-color: #495057;
  --scroller-background-color: white;
  --scroller-thumb-color: #e4e2e2;
  --scroller-hover-color: #a8a8a8;
  --profile-background-color: #eee;
  --dropdown-menu-item-color: #eee;
}

[data-theme="dark"] {
  --top-bottom-background-color: #2d333b;
  --compiler-background-color: #0d1117;
  --codeEdit-background-color: #22272e;
  --top-button-background-color: #2d333b;
  --cm-editor-background-color: @oneDark;
  --separator-background-color: #262a30;
  --text-background-color: #282c34;
  --default-border: 1px solid black;
  --text-color: #ffffff; 
   --scroller-background-color: #2d333b;
  --scroller-thumb-color: #707983;
  --scroller-hover-color: #9eaab6;
  --profile-background-color:@oneDark;
  --dropdown-menu-item-color: #2d333b;
}
</style>
