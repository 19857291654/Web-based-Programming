<template>
  <div class="codeEdit">
    <div class="top-button">
      <TopButton ></TopButton>
    </div> 

    <div class="code">
      <div class="code-write" :style="{ width: editorWidth }">
        <CodeMirror ></CodeMirror>
      </div>

      <div class="separator separator-vertical" @mousedown="startDragHorizontal">
      </div>

      <div class="outIput" :style="{ width: consoleWidth }">
        <div class="code-input" :style="{ height: inputHeight }">
          <textarea class="text" id="code-input" v-model="inputValue" placeholder="在此输入"></textarea>
        </div>

        <div class="separator separator-horizontal" @mousedown="startDragVertical" ></div>

        <div class="code-console" :style="{ height: consoleHeight }">
          <textarea class="text" id="code-console" v-model="outputValue"></textarea>
        </div>
      </div>
    </div>
  </div>
</template>


<script lang="ts" setup>
import { ref, computed } from 'vue';
import CodeMirror from './CodeMirror.vue';
import TopButton from '../TopButton.vue';
import { useCodeOutputStore } from '../../store/codeOutput';


const codeOutputStore = useCodeOutputStore();

const editorWidth = ref('calc(50% - 10px)');
const consoleWidth = ref('calc(50% - 10px)');

const inputHeight = ref('calc(20% - 10px)');
const consoleHeight = ref('calc(80% - 10px)');
const inputHeightMin = ref(50); // 使用数值而非带单位的字符串
const inputHeightMax = ref(400);

//水平分隔线拖动
const startDragHorizontal = (event: MouseEvent) => {
  const containerWidth = document.querySelector('.code')?.clientWidth || 1;
  const startX = event.clientX;

  // 检查 editorWidth.value 是否为空，为空时提供一个默认值 "50% - 10px"
  let currentEditorWidth = editorWidth.value ? parseFloat(editorWidth.value.match(/\d+/)?.[0] || '50') : 50;

  const doDrag = (e: MouseEvent) => {
    const deltaX = e.clientX - startX;
    let newWidthPercentage = (currentEditorWidth * containerWidth / 100 + deltaX) / containerWidth * 100;

    // 限制宽度范围在最小和最大百分比之间
    newWidthPercentage = Math.max(20, Math.min(newWidthPercentage, 80));

    // 更新两侧宽度
    editorWidth.value = `calc(${newWidthPercentage}% - 10px)`;
    consoleWidth.value = `calc(${100 - newWidthPercentage}% - 10px)`;
  };

  document.addEventListener('mousemove', doDrag);
  document.addEventListener('mouseup', () => document.removeEventListener('mousemove', doDrag));
};

const startDragVertical = (event: MouseEvent) => {
  const containerHeight = document.querySelector('.outIput')?.clientHeight || 1;
  const startY = event.clientY;
  const startInputHeight = parseFloat(inputHeight.value.match(/\d+/)?.[0] || '20') / 100 * containerHeight;

  const doDrag = (e: MouseEvent) => {
    const deltaY = e.clientY - startY;
    let newInputHeight = (startInputHeight + deltaY) / containerHeight * 100;

    // 限制高度在最小和最大百分比之间
    const minPercentage = (inputHeightMin.value / containerHeight) * 100;
    const maxPercentage = (inputHeightMax.value / containerHeight) * 100;

    newInputHeight = Math.max(minPercentage, Math.min(newInputHeight, maxPercentage));

    // 更新输入框和控制台的高度
    inputHeight.value = `calc(${newInputHeight}% - 10px)`;
    consoleHeight.value = `calc(${100 - newInputHeight}% - 10px)`;
  };

  document.addEventListener('mousemove', doDrag);
  document.addEventListener('mouseup', () => document.removeEventListener('mousemove', doDrag));
};


const outputValue = computed({
  get: () => {
    const runOutput = codeOutputStore.runOutput;
    const compileOutput = codeOutputStore.compileOutput;
    const defaultOutput = codeOutputStore.defaultOutput;
    // 如果所有输出为空，则返回默认输出
    if (!runOutput && !compileOutput) {
      return defaultOutput;
    }

    return runOutput || compileOutput || defaultOutput;
  },/* eslint-disable */
  set: () => { } // 空的 set 方法
});


const inputValue = computed({
  get: () => {
    return codeOutputStore.input
  },
  set: (newValue) => {
    codeOutputStore.input = newValue;
  }
});


</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang="less">
@codeColor: #fdfcfb;

.codeEdit {
  // overflow: hidden;
  width: 100%;
  height: 100%;
  background-color: var(--codeEdit-background-color);

  overflow: hidden;
}

.top-button {
  height: 10%;
  margin-bottom: 2.5%;
  background-color: var(--top-button-background-color);
}

.code {
  display: flex;
  height: 80%;
  background-color: var(--codeEdit-background-color);
  box-sizing: border-box;
  // overflow: hidden;
}

.code-write {
  background-color: var(--codeEdit-background-color);
  font-size: 14px;
  font-family: Consolas, monospace !important;
  box-sizing: border-box;
}

.separator {
  // box-sizing: border-box;
  background-color: var(--separator-background-color);
  background-repeat: no-repeat;
  background-position: center;
  margin: 5px
}

.separator-vertical {
  width: 10px;
  cursor: ew-resize;
  background-image: url('@/assets/image/左右拖拉.png');
  background-size: 300% 7%;

}

.outIput {
  // display: flex;
  padding: 2px;
  background-color: var(--codeEdit-background-color);
  box-sizing: border-box;
}

.code-input {
  height: 50%;
  width: 100%;
}

.separator-horizontal {
  height: 10px;
  cursor: ns-resize;
  background-image: url('@/assets/image/上下拖拉.png');
  background-size: 6% 300%;
}


.code-console {
  box-sizing: border-box;
  height: 50%;
  width: 100%;
}


.text {
  box-sizing: border-box;
  padding: 20px;
  display: block;
  width: 100%;
  height: 100%;
  color: var(--text-color);
  border: var(--default-border);
  outline: none;
  overflow: auto;
  resize: none;
  transition: box-shadow 0.3s ease;
  background-color: var(--text-background-color);
}

.text:focus {
  box-shadow: 0 0 5px rgba(0, 123, 255, 0.7);
}

.text::-webkit-scrollbar {
  width: 10px;
  height: 10px;
}

.text::-webkit-scrollbar-thumb {
  background-color: var(--scroller-thumb-color);
  border-radius: 4px;
  cursor: pointer;
}

.text::-webkit-scrollbar-thumb:hover {
  background-color: var(--scroller-hover-color);
  cursor: pointer;
}

.text::-webkit-scrollbar-track {
  background-color: var(--scroller-background-color);
  cursor: pointer;

}
</style>
