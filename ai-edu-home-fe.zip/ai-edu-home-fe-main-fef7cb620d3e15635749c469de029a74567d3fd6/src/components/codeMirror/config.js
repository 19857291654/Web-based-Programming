export const initHtml = '<p>请输入内容...</p>';
