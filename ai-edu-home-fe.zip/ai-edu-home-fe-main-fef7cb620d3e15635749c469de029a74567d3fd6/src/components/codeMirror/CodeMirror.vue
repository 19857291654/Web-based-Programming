<template>
    <div class="container">
        <codemirror v-if="languageStore.theme === 'light'" class="code-mirror" v-model="languageStore.code"
            placeholder="此处编写代码" :style="{ height: '400px' }" :autofocus="true" :indent-with-tab="true" :tab-size="3"
            :extensions="defaultExtensions" @ready="handleReady" @focus="handleFocus" @blur="handleBlur"
            @change="handleChange" />

        <codemirror v-if="languageStore.theme === 'dark'" class="code-mirror" v-model="languageStore.code"
            placeholder="此处编写代码" :style="{ height: '400px' }" :autofocus="true" :indent-with-tab="true" :tab-size="3"
            :extensions="darkExtensions" @ready="handleReady" @focus="handleFocus" @blur="handleBlur"
            @change="handleChange" />
    </div>
</template>

<script lang="ts">
import { defineComponent, onMounted, watch } from 'vue';
import { Codemirror } from 'vue-codemirror';
import { javascript } from '@codemirror/lang-javascript';
import { oneDark } from '@codemirror/theme-one-dark';
import { undo as codemirrorUndo, redo as codemirrorRedo } from '@codemirror/commands';
import { python } from '@codemirror/lang-python';
import { java } from '@codemirror/lang-java';
import { cpp } from '@codemirror/lang-cpp';
import { autocompletion } from '@codemirror/autocomplete';
import { useLanguageStore } from "@/store/languageStore";
import { useCodeOutputStore } from "@/store/codeOutput";
import EventBus from "@/utils/eventBus";
import { useChatAIStore } from '@/store/chatAIStore';


export default defineComponent({
    components: {
        Codemirror,
    },
    setup() {
        // eslint-disable-next-line
        let view: any = null;
        const languageStore = useLanguageStore();
        const codeOutputStore = useCodeOutputStore();
        const chatAIStore = useChatAIStore();

        let defaultExtensions = [
            cpp(),
            javascript(),
            python(),
            java(),
            autocompletion(),
        ];
        let darkExtensions = [
            cpp(),
            javascript(),
            python(),
            java(),
            autocompletion(),
            oneDark
        ];

        // eslint-disable-next-line
        const handleReady = (payload: any) => {
            view = payload.view;
        };

        // 处理聚焦
        // eslint-disable-next-line
        const handleFocus = () => {
            const cmEditor = document.querySelector('.cm-editor') as HTMLElement;
            if (cmEditor) {
                cmEditor.classList.add('focused'); // 添加 focused 类
            }
        };

        // 处理失去焦点
        // eslint-disable-next-line
        const handleBlur = () => {
            const cmEditor = document.querySelector('.cm-editor') as HTMLElement;
            if (cmEditor) {
                cmEditor.classList.remove('focused'); // 移除 focused 类
            }

        };

        //  处理代码改变
        const handleChange = () => {
            if (!chatAIStore.codeChanged) {
                chatAIStore.codeChanged = true;
                EventBus.emit('viewAI')
            }

        };

        onMounted(() => {
            EventBus.on('resetCode', () => {
                switch (languageStore.language) {
                    case 'C':
                        languageStore.code = languageStore.cCode;
                        break;
                    case 'C++':
                        languageStore.code = languageStore.cppCode;
                        break;
                    case 'Python3':
                        languageStore.code = languageStore.pythonCode;
                        break;
                    default:
                        break;
                }
                codeOutputStore.reset();
            });

            EventBus.emit('resetCode')

            EventBus.on('undo', () => {
                if (view) {
                    codemirrorUndo(view); // Perform undo using Codemirror's undo command
                }
            });

            EventBus.on('redo', () => {
                if (view) {
                    codemirrorRedo(view); // 恢复操作
                }
            });
        });

        watch(() => languageStore.language, () => {
            EventBus.emit('resetCode')
        });

        return {
            languageStore,
            codeOutputStore,
            chatAIStore,
            defaultExtensions,
            darkExtensions,
            handleReady,
            handleFocus,
            handleBlur,
            handleChange
        };
    },
});
</script>

<style scoped lang="less">
@dark-color: black;

.container {
    box-sizing: border-box;
    width: 100%;
    height: 100%;
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    overflow: hidden;
    text-align: left;
    padding: 2px;
}

::v-deep .cm-editor {
    width: 100%;
    height: 100%;
    outline: none;
    transition: box-shadow 0.3s ease;
    /* 添加过渡效果 */
    border: var(--default-border);
    background-color: var(--cm-editor-background-color);
    box-sizing: border-box;
}


::v-deep .cm-scroller {
    overflow-y: auto;
    font-family: Consolas, monospace;
}


::v-deep .cm-editor.focused {
    box-shadow: 0 0 5px rgba(0, 123, 255, 0.7);
    /* 焦点时的阴影 */
}

.dark-theme {
    background-color: @dark-color;
}


::v-deep .cm-scroller::-webkit-scrollbar {
    width: 10px;
    /* Scrollbar width */
    height: 10px;
    /* Scrollbar height */
}

::v-deep .cm-scroller::-webkit-scrollbar-thumb {
    background-color: var(--scroller-thumb-color);
    /* Scrollbar color */
    border-radius: 4px;
    /* Rounded corners */
}

::v-deep .cm-scroller::-webkit-scrollbar-thumb:hover {
    background-color: var(--scroller-hover-color);
    /* Scrollbar color */
}

::v-deep .cm-scroller::-webkit-scrollbar-track {
    background-color: var(--scroller-background-color);
    /* Scrollbar color */
}
</style>