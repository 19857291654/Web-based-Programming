<template>
    <div style="border: 1px solid #ccc">
        <Editor v-model="valueHtml" aria-hidden="false" style="height: 450px; overflow: auto"
            :defaultConfig="editorConfig" :mode="mode" @onCreated="handleCreated" />
    </div>
</template>

<script setup>
import '@wangeditor/editor/dist/css/style.css'; // 引入 css

import { onBeforeUnmount, ref, shallowRef, defineEmits, defineProps, watch } from 'vue';
import { Editor } from '@wangeditor/editor-for-vue';
import { initHtml } from './config';

const props = defineProps(['task']);
const emit = defineEmits(['value-updated']); // 定义 value-updated 事件

const editorRef = shallowRef();

// 内容 HTML
const valueHtml = ref(initHtml);
const mode = 'simple';
// 模拟 ajax 异步获取内容

const editorConfig = {
    placeholder: '默认初始化值',
}

// 组件销毁时，也及时销毁编辑器
onBeforeUnmount(() => {
    const editor = editorRef.value;
    if (editor == null) return;
    editor.destroy();
});

watch(props.task, () => {
    initContent();
});

const handleCreated = (editor) => {
    editorRef.value = editor; // 记录 editor 实例，重要！
    initContent();
    setTimeout(() => {
        toolbarDisabled();
    }, 100);
};

const initContent = () => {
    valueHtml.value = props.task.editorContent;
};

const toolbarDisabled = () => {
    const editor = editorRef.value;
    editor.disable();
};

</script>

<style scoped>
/* 覆盖编辑器的默认样式，设置深色背景和白色文字 */
::v-deep .w-e-text-container {
    /* color: var(--text-color); */
    background-color: #ccc;
}

/* 覆盖编辑器滚动条样式 */

::v-deep .w-e-text-container>div::-webkit-scrollbar {
    width: 10px;
    /* Scrollbar width */
    height: 10px;
    /* Scrollbar height */
}

::v-deep .w-e-text-container>div::-webkit-scrollbar-thumb {
    background-color: var(--scroller-thumb-color);
    border-radius: 4px;
}

::v-deep .w-e-text-container>div::-webkit-scrollbar-thumb:hover {
    background-color: var(--scroller-hover-color);

}

::v-deep .w-e-text-container>div::-webkit-scrollbar-track {
    background-color: var(--scroller-background-color);
}
</style>