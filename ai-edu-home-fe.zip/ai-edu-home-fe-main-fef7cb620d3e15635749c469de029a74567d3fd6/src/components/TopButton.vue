<template>
    <div class="container">
        <div class="left">
            <el-tooltip content="撤销(返回上一步)" placement="top">
                <el-button :color="buttonColor" plain @click="EventBus.emit('undo')">
                    <el-icon>
                        <img class="responsive-image" src="../assets/svg/return-left.svg" alt="">
                    </el-icon>
                </el-button>
            </el-tooltip>

            <el-tooltip content="恢复(恢复上一步)" placement="top">
                <el-button :color="buttonColor" plain @click="EventBus.emit('redo')">
                    <el-icon>
                        <!-- <ArrowRightBold /> -->
                        <img class="responsive-image" src="../assets/svg/return-right.svg" alt="">
                    </el-icon>
                </el-button>
            </el-tooltip>

            <el-button :color="buttonColor" plain @click="runCode" :loading="loading" :disabled="loading">
                <el-icon>
                    <VideoPlay />
                </el-icon>
                点击运行
            </el-button>

            <el-button :color="buttonColor" plain @click="EventBus.emit('resetCode')">
                <el-icon>
                    <Refresh />
                </el-icon>
                重置
            </el-button>


            <el-select :effect="languageStore.theme" v-model="languageStore.language"
                style="width: 140px ;margin:0px 10px">
                <el-option label="C语言" value="C" seleted></el-option>
                <el-option label="C++语言" value="C++"></el-option>
                <el-option label="Python3语言" value="Python3"></el-option>
            </el-select>
            <el-button :color="buttonColor" plain @click="AIchat = !AIchat">
                <el-icon>
                    <ChatDotRound />
                </el-icon>
                AI检查
            </el-button>
            <el-button class="describe" :color="buttonColor" plain
                @click="taskInfoStore.taskChoose = !taskInfoStore.taskChoose">

                选择作业
            </el-button>
            <el-button :color="buttonColor" plain @click="openWorkCenter">
                作业中心
            </el-button>

        </div>

        <div class="right">
            <transition name="slide">
                <task-show v-if="drawerVisible" :task="taskInfoStore">
                    <template #default="{ task }">
                        <div style="display: flex; justify-content: flex-end;">
                            <el-tooltip content="持久化显示题目要求" placement="top">
                                <el-button :color="buttonColor" plain @click="notificationTask(taskInfoStore)">
                                    显示题目要求
                                </el-button>
                            </el-tooltip>
                        </div>
                        <wangEditor :task="task" />
                    </template>
                </task-show>

            </transition>
            <div v-show="!drawerVisible">
                <el-button class="close-button2" @click="openDrawer">
                    &lt;&lt;
                </el-button>
            </div>

            <transition name="slide">
                <div class="AIchat" v-if="AIchat">
                    <!-- 弹出框左侧的关闭按钮 -->
                    <el-button class="close-button" @click="toggleChat" :disabled='chatAIStore.loading'>
                        ×
                    </el-button>
                    <div class="content">
                        <div class="top">
                            <p style="color: aliceblue;">当前代码的问题检查</p>
                        </div>
                        <div class="chat">
                            <ChatDrawer></ChatDrawer>
                        </div>
                    </div>
                </div>
            </transition>
        </div>


    </div>
</template>
<script lang="ts" setup>
import { ref, onMounted } from 'vue';
import { useLanguageStore } from '@/store/languageStore';
import { useUserInfoStore } from '@/store/userInfoStore';
import { useCodeOutputStore } from '@/store/codeOutput';
import { useChatAIStore } from '@/store/chatAIStore';
import EventBus from '@/utils/eventBus';
import { VideoPlay, Refresh, ChatDotRound } from '@element-plus/icons-vue'; // 引入图标
import { ElSelect, ElOption, ElMessage, ElNotification } from 'element-plus';
import { compileCode } from '@/api/compileCode'; // 引入编译代码的函数
import taskShow from './show/taskShow.vue';
import { useTaskInfoStore } from '@/store/taskInfoStore';
import ChatDrawer from './drawer/ChatDrawer.vue';
import { useRouter } from 'vue-router'
import WangEditor from './codeMirror/WangEditor.vue';

const router = useRouter();
const AIchat = ref(false);
const languageStore = useLanguageStore();
const userInfoStore = useUserInfoStore();
const taskInfoStore = useTaskInfoStore();
const codeOutputStore = useCodeOutputStore();
const chatAIStore = useChatAIStore();
const loading = ref(false); // 控制按钮加载状态
// const chatLoading = ref(false); // 控制按钮加载状态
let buttonColor = ref('#626aef'); // 按钮颜色


const drawerVisible = ref(false); // 控制抽屉的显示状态

onMounted(() => {
    document.body.style.overflow = 'hidden'; // 禁用滚动
    EventBus.on('viewAI', () => {
        AIchat.value = false
    });
    EventBus.on('closeTaskShow', () => {
        drawerVisible.value = false;
    });
    EventBus.on('openTaskDetailed', () => {
        openDrawer();
    });
});


// 打开 Drawer 时的操作
const openDrawer = () => {
    if (taskInfoStore.choosedId === -1) {
        ElMessage({
            message: '未选择任何题目',
            type: 'warning',
        })
        return; // 如果未选择任务，直接返回
    }
    if (!drawerVisible.value)
        drawerVisible.value = true; // 打开 Drawer
};


//代码运行      
const runCode = async () => {
    try {
        loading.value = true; // 开始加载状态
        const timeout = new Promise<null>((_, reject) =>
            setTimeout(() => reject(new Error('请求超时')), 10000) // 10 秒超时
        );


        const userId = userInfoStore.id;
        // 编译代码与超时一起等待
        const result = await Promise.race([compileCode(userId, taskInfoStore.knowledgePointId, languageStore.language, languageStore.code, codeOutputStore.input), timeout]);
        console.log('编译结果:', result);
        if (!result) return;

        const data = result.data.data;

        if (data.runOutput) {
            codeOutputStore.runOutput = data.runOutput;
            codeOutputStore.compileOutput = '';

        } else if (data.compileOutput) {
            codeOutputStore.compileOutput = data.compileOutput;
            codeOutputStore.runOutput = '';
        }
    } catch (error) {
        console.error('编译失败:', error);
        if ((error as Error).message === '请求超时') {
            ElMessage({
                showClose: true,
                message: '请求超时.',
                type: 'error',
            })
            // 可以根据需要处理超时错误
            codeOutputStore.compileOutput = '请求超时，请稍后再试';
        }
    } finally {
        loading.value = false; // 请求完成后取消加载状态
    }
};

//切换显示与隐藏
function toggleChat() {
    AIchat.value = !AIchat.value;  // 切换显示与隐藏
}

//长久化显示题目要求
// eslint-disable-next-line
function notificationTask(data: any) {
    ElNotification({
        title: `作业${data.id} 题目要求:`,
        message: data.description,
        duration: 0,
    })
    drawerVisible.value = false;
}
function openWorkCenter() {
    const url = router.resolve({ path: '/workCenter' }).href; // 生成完整 URL
    window.open(url, '_blank'); // 在新标签页打开
}

</script>
<style scoped lang="less">
.container {
    padding: 0px 20px;
    height: 100%;
    display: flex;
    align-items: center;
    justify-content: space-between;
    overflow: hidden;

    button {
        cursor: pointer;
    }
}


.right {
    display: flex;
    align-items: center;
    /* 垂直居中 */

    .describe {
        margin-left: 12px;
    }
}

.task-show {
    position: absolute;

    top: 45px;
    bottom: 45px;
    right: 0px;
    // background-color: var(--codeEdit-background-color);
    width: 40%;
    height: calc(100% - 100px);
    transition: all 0.3s ease; // 添加平滑过渡效果
}

.AIchat {
    position: absolute;
    top: 55px;
    bottom: 45px;
    right: 0px;
    background-color: var(--codeEdit-background-color);
    width: 40%;
    height: calc(100% - 100px);
    transition: all 0.3s ease; // 添加平滑过渡效果

    /* 关闭按钮 */
    .close-button {
        position: absolute;
        top: 0px;
        left: -20px;
        /* 将按钮放置到左侧突出部分 */
        width: 30px;
        height: 30px;
        background-color: #ccc;
        /* 红色背景 */
        color: white;
        border-radius: 50%;
        /* 使按钮为圆形 */
        display: flex;
        justify-content: center;
        align-items: center;
        cursor: pointer;
        font-size: 20px;
        z-index: 10;
    }

    /* 关闭按钮 hover 效果 */
    .close-button:hover {
        background-color: #ee7171;
    }

    .content {
        .top {
            display: flex;
            justify-content: flex-end;
            /* 将内容靠右对齐 */
            margin: 20px 20px;
            /* 上下 10px，左右 20px */
        }

    }
}


.responsive-image {
    max-width: 100%;
    max-height: 100%;
    display: block;
    /* 移除图片下方的空白 */
    object-fit: contain;
    /* 确保图片完整显示，不会被裁剪 */
}



/* 定义动画的初始和结束状态 */
.slide-enter-from,
.slide-leave-to {
    transform: translateX(100%);
    /* 从右侧滑入 */
    opacity: 0;
}

.slide-enter-to,
.slide-leave-from {
    transform: translateX(10);
    /* 显示在页面中 */
    opacity: 1;
}

/* 定义动画的过渡效果 */
.slide-enter-active,
.slide-leave-active {
    transition: transform 0.4s ease, opacity 0.4s ease;
}

.close-button2 {
    position: absolute;
    top: 45px;
    right: 0px;
    /* 将按钮放置到左侧突出部分 */
    width: 30px;
    height: 30px;
    background-color: #ccc;
    /* 红色背景 */
    color: white;
    border-radius: 50%;
    /* 使按钮为圆形 */
    display: flex;
    justify-content: center;
    align-items: center;
    cursor: pointer;
    font-size: 20px;
    z-index: 10;
}

/* 关闭按钮 hover 效果 */
.close-button2:hover {
    background-color: #626aef;
}
</style>