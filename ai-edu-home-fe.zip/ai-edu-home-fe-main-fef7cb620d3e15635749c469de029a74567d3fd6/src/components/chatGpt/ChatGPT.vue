<template>
  <div class="container">
    <div class="chat-container">
      <el-button :color="buttonColor" plain @click="router.push('/')" class="return" >
          <el-icon>
            <HomeFilled />
          </el-icon>
          返回
        </el-button>
      <!-- 消息显示区 -->
      <div class="chat-messages">
        
        <div v-for="(message, index) in messages" :key="index" :class="['message', message.role]">
          <div class="message-content">
            <p>{{ message.content }}</p>
          </div>
        </div>
      </div>

      <!-- 用户输入区 -->
      <div class="chat-box">
        <textarea v-model="userInput" placeholder="请输入您的问题..." class="input-box"></textarea>
        <el-button :disabled="loading" :color="buttonColor" plain @click="fetchResponse" class="send">
          <el-icon>
            <Promotion />
          </el-icon>
          {{ loading ? '请求中...' : '发送' }}
        </el-button>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue';
import { fetchChatGPTResponse } from '../../utils/chatGpt';
import { Promotion,HomeFilled } from '@element-plus/icons-vue'; // 引入图标
import { useRouter } from 'vue-router';

const router = useRouter();
const userInput = ref('');
const messages = ref([]);
const loading = ref(false);
let buttonColor = ref('#282c34'); // 按钮颜色
const fetchResponse = async () => {
  if (!userInput.value.trim()) {
    alert('请输入您的问题！');
    return;
  }

  // 添加用户消息
  messages.value.push({ role: 'user', content: userInput.value });
  userInput.value = ''; // 清空输入框

  loading.value = true;

  try {

    const responseContent = await fetchChatGPTResponse(messages.value);

    // 添加 GPT 消息
    messages.value.push({ role: 'assistant', content: responseContent });
  } catch (err) {
    messages.value.push({ role: 'assistant', content: err.message });
  } finally {
    loading.value = false;
  }
};
</script>

<style lang="less" scoped>
.container {
  width: 100vw;
  height: 100vh;
  background-color: var(--top-bottom-background-color);
  display: flex;
  justify-content: center;

  .chat-container {
    display: flex;
    flex-direction: column;
    align-items: center;
    width: 80%;
    height: 100%;
    background-color: var(--cm-editor-background-color);

    .return{
      position: relative;
      right: 45%;
    }
  }
}

.chat-messages {
  width: 100%;
  height: 100%;
  overflow-y: auto;
  display: flex;
  flex-direction: column;
  gap: 10px;
  background-color: var(--cm-editor-background-color);


  .message {
    display: flex;
    flex-direction: column;
    gap: 5px;
  }

  .message-content {
    max-width: 70%;
    padding: 10px;
    border-radius: 8px;
    word-wrap: break-word;
    font-size: 16px;
  }

  .message.user .message-content {
    background-color: #409eff;
    color: white;
    align-self: flex-end;
    /* 用户消息靠右显示 */
  }

  .message.assistant .message-content {
    background-color: #f5f5f5;
    color: #333;
    align-self: flex-start;
    /* GPT 消息靠左显示 */
  }

}


.chat-box {
  position: absolute;
  bottom: 0;
  width: 60%;
  gap: 10px;
  padding: 10px;
  border-radius: 1.5rem;
  background-color: var(--top-bottom-background-color);

  .input-box {
    padding: 10px;
    box-sizing: border-box;
    width: 100%;
    height: 100px;
    font-size: 16px;
    border-radius: 5px;
    outline: none;
    resize: none;
    background-color: var(--top-bottom-background-color);
    color: var(--text-color);

  }

  .send {
    margin: 10px 0;
    position: relative;
    left: 45%;
  }
}

.input-box,
.chat-messages {
  &::-webkit-scrollbar {
    width: 10px;
    height: 10px;
  }

  &::-webkit-scrollbar-thumb {
    background-color: var(--scroller-thumb-color);
    border-radius: 4px;
    cursor: pointer;
  }

  &::-webkit-scrollbar-thumb:hover {
    background-color: var(--scroller-hover-color);
    cursor: pointer;
  }

  &::-webkit-scrollbar-track {
    background-color: var(--scroller-background-color);
    cursor: pointer;
  }
}
</style>
