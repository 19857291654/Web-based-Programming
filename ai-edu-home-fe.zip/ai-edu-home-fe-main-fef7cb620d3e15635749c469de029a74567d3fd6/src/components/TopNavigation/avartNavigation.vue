<template>
    <div class="userInfo">
        <div class="left">
            <!-- 使用插槽 -->
            <slot name="left">
                <span>默认标题</span> <!-- 如果没有插槽内容，这里展示默认值 -->
            </slot>
        </div>

        <div class="center">
            <!-- 使用插槽 -->
            <slot name="center-content">
                <span></span> <!-- 如果没有插槽内容，这里展示默认值 -->
            </slot>
        </div>

        <div class="right">
            <button @click="changeTheme()" id="theme" class="moon"></button>

            <img @mouseenter="showMenu = true" @mouseleave="showMenu = false"
                :src="require(`@/assets/svg/头像${currentAvatar}.svg`)" alt="用户头像" @click="changeImg" />

            <!-- 弹出的功能区域 -->
            <div @mouseenter="showMenu = true" @mouseleave="showMenu = false" v-if="showMenu" class="dropdown-menu">
                <span>{{ userInfoStore.username }}</span>
                <p></p>
                <!-- 动态控制作业中心按钮显示 -->
                <p></p>
                <button @click="accountLogout">退出登录</button>
            </div>
            <el-dialog v-model="dialogVisible" width="300px">
                <span>你确定要退出登录吗？</span>
                <template #footer> <!-- 使用新的插槽语法 -->
                    <el-button @click="dialogVisible = false">取消</el-button>
                    <el-button type="primary" @click="confirmLogout">确定</el-button>
                </template>
            </el-dialog>
        </div>
    </div>
</template>


<script lang="ts" setup>
import { ref } from 'vue';
import { logout } from '@/api/account';
import { ElMessage, ElDialog } from 'element-plus';
import { useUserInfoStore } from '@/store/userInfoStore';
import { useLanguageStore } from '@/store/languageStore';

const userInfoStore = useUserInfoStore();
const languageStore = useLanguageStore();

const showMenu = ref(false);
const avatar = ['魔术师', '巫师', '像素人', '杂技师'];
const imageArray = ['moon', 'sun-moon', 'sun', 'sun-moon'];
const index = ref(1);
const authToken = localStorage.getItem('authToken');
// 当前显示的头像，初始头像为第一个
const currentAvatar = ref<string>('巫师'); // 使用相对路径
const dialogVisible = ref(false);
let image = ref(0); // 图标




// 根据选择的头像切换头像
function changeImg() {
    index.value = (index.value + 1) % 4;
    currentAvatar.value = avatar[index.value];
}

function accountLogout() {
    dialogVisible.value = true
}

async function confirmLogout() {
    dialogVisible.value = false
    const res = await logout(authToken as string);
    console.log('logout', res);
    debugger;
    if (res.data.code === 200) {
        localStorage.removeItem('authToken');
        window.location.href = '/login';
        ElMessage.success('退出登录成功');
    }
}

function changeTheme() {
    if (image.value == 1 || image.value == 3) {
        languageStore.theme = languageStore.theme === 'light' ? 'dark' : 'light';
    }
    document.getElementById('theme')?.classList.remove(imageArray[image.value]);
    image.value = (image.value + 1) % 4;
    document.getElementById('theme')?.classList.add(imageArray[image.value]);
}

</script>

<style scoped lang="less">
.userInfo {
    color: var(--text-color);
    display: flex;
    justify-content: space-between;
    align-items: center;
    height: 100%;
    width: 100%;
    box-sizing: border-box;


    .left,
    .right {
        width: 100px;
        margin: 5px 2%;
    }

    .center {
        display: flex;
        justify-content: center;
        align-items: center;
        /* 使内容垂直居中 */
    }

    .right {
        display: flex;
        justify-content: space-around;

        #theme {
            width: 40px;
            height: 40px;
            background-size: contain;
            background-position: center;
            background-repeat: no-repeat;
            border: none;
            border-radius: 10px;
        }

        img {
            flex-direction: column;
            justify-content: center;
            display: flex;
            border-radius: 10px;
            height: 40px;
            background-size: contain;
        }

        .dropdown-menu {
            position: absolute;
            top: 43px;
            right: 0px;
            padding: 10px;
            background-color: var(--text-background-color);
            border: var(--default-border);

            span {
                font-size: 14px;
                line-height: 30px;
                display: block;
                width: 100px;
                height: 30px;
                background-color: var(--dropdown-menu-item-color);
                color: var(--text-color);
            }

            p {
                margin: 10px 0;
                display: block;
            }

            button {
                display: block;
                width: 100px;
                height: 30px;
                background-color: var(--dropdown-menu-item-color);
                color: var(--text-color);
                border: none;
                cursor: pointer;
            }
        }
    }

    .sun {
        background-image: url('@/assets/svg/太阳.svg');
    }

    .moon {
        background-image: url('@/assets/svg/月亮.svg');
    }

    .sun-moon {
        background-image: url('@/assets/svg/太阳-月亮.svg');
    }

}

</style>