<template>
    <div class="task">
        <div class="left">

            <div class="task-container" ref="taskContainer" @mousedown="onMouseDown" @touchstart="onTouchStart"
                @mousemove="onMouseMove" @touchmove="onTouchMove" @mouseup="onMouseUp" @mouseleave="onMouseUp"
                @touchend="onMouseUp">
                <div v-for="task in tasks" :key="task.id" class="task-item">
                    <button @click="changeTask(task, task.id)" class="button-item"
                        :class="{ choose: selectedTaskId === task.id, unChoose: selectedTaskId !== task.id }" id="task">
                        <span v-if="task.status === 'succeed'">✖️</span>
                        <span v-else>✔️</span>
                    </button>
                </div>
            </div>
        </div>

        <div class="right">
            <el-button :color="buttonColor" plain @click="nextTasks">
                下一次作业
            </el-button>
            <el-button :color="buttonColor" plain @click="historyTasks">
                历史作业
            </el-button>
        </div>
    </div>

</template>
<script lang="ts" setup>
import { ref, onMounted } from 'vue';
import { getAssignments } from '@/api/assignments';
import { useTaskInfoStore } from '@/store/taskInfoStore';
import { ElMessage } from 'element-plus';
import EventBus from '@/utils/eventBus';


const taskInfoStore = useTaskInfoStore();

const tasks = ref();
const selectedTaskId = ref(-1); // 选中的作业id
let buttonColor = ref('#626aef'); // 按钮颜色


onMounted(async () => {
    // 获取作业
    const assignments = await getAssignments();
    tasks.value = assignments.data.data;
    // tasks.value = [{
    //     "id": 1,
    //     "description": "更新后的描述！",
    //     "knowledgePointId": "22222"
    // }, {
    //     "id": 2,
    //     "description": "更新后的描述！",
    //     "knowledgePointId": "22222"
    // }, {
    //     "id": 3,
    //     "description": "更新后的描述！",
    //     "knowledgePointId": "22222"
    // }, {
    //     "id": 1,
    //     "description": "更新后的描述！",
    //     "knowledgePointId": "22222"
    // }, {
    //     "id": 1,
    //     "description": "更新后的描述！",
    //     "knowledgePointId": "22222"
    // }, {
    //     "id": 1,
    //     "description": "更新后的描述！",
    //     "knowledgePointId": "22222"
    // }, {
    //     "id": 1,
    //     "description": "更新后的描述！",
    //     "knowledgePointId": "22222"
    // }, {
    //     "id": 1,
    //     "description": "更新后的描述！",
    //     "knowledgePointId": "22222"
    // }, {
    //     "id": 1,
    //     "description": "更新后的描述！",
    //     "knowledgePointId": "22222"
    // }, {
    //     "id": 1,
    //     "description": "更新后的描述！",
    //     "knowledgePointId": "22222"
    // }, {
    //     "id": 1,
    //     "description": "更新后的描述！",
    //     "knowledgePointId": "22222"
    // }, {
    //     "id": 1,
    //     "description": "更新后的描述！",
    //     "knowledgePointId": "22222"
    // }, {
    //     "id": 1,
    //     "description": "更新后的描述！",
    //     "knowledgePointId": "22222"
    // }, {
    //     "id": 1,
    //     "description": "更新后的描述！",
    //     "knowledgePointId": "22222"
    // }, {
    //     "id": 1,
    //     "description": "更新后的描述！",
    //     "knowledgePointId": "22222"
    // }, {
    //     "id": 1,
    //     "description": "更新后的描述！",
    //     "knowledgePointId": "22222"
    // }, {
    //     "id": 1,
    //     "description": "更新后的描述！",
    //     "knowledgePointId": "22222"
    // }, {
    //     "id": 1,
    //     "description": "更新后的描述！",
    //     "knowledgePointId": "22222"
    // }, {
    //     "id": 1,
    //     "description": "更新后的描述！",
    //     "knowledgePointId": "22222"
    // }, {
    //     "id": 1,
    //     "description": "更新后的描述！",
    //     "knowledgePointId": "22222"
    // }, {
    //     "id": 1,
    //     "description": "更新后的描述！",
    //     "knowledgePointId": "22222"
    // }, {
    //     "id": 1,
    //     "description": "更新后的描述！",
    //     "knowledgePointId": "22222"
    // }, {
    //     "id": 1,
    //     "description": "更新后的描述！",
    //     "knowledgePointId": "22222"
    // }, {
    //     "id": 1,
    //     "description": "更新后的描述！",
    //     "knowledgePointId": "22222"
    // }, {
    //     "id": 1,
    //     "description": "更新后的描述！",
    //     "knowledgePointId": "22222"
    // }, {
    //     "id": 1,
    //     "description": "更新后的描述！",
    //     "knowledgePointId": "22222"
    // }, {
    //     "id": 1,
    //     "description": "更新后的描述！",
    //     "knowledgePointId": "22222"
    // }, {
    //     "id": 1,
    //     "description": "更新后的描述！",
    //     "knowledgePointId": "22222"
    // }, {
    //     "id": 1,
    //     "description": "更新后的描述！",
    //     "knowledgePointId": "22222"
    // }, {
    //     "id": 1,
    //     "description": "更新后的描述！",
    //     "knowledgePointId": "22222"
    // }, {
    //     "id": 1,
    //     "description": "更新后的描述！",
    //     "knowledgePointId": "22222"
    // }, {
    //     "id": 1,
    //     "description": "更新后的描述！",
    //     "knowledgePointId": "22222"
    // }];
    console.log('作业数据:', tasks.value);

})

const taskContainer = ref<HTMLDivElement | null>(null);
const isDragging = ref(false);
const startX = ref(0);
const scrollLeft = ref(0);

function onMouseDown(e: MouseEvent) {
    isDragging.value = true;
    startX.value = e.pageX; // 鼠标起始位置
    if (taskContainer.value) {
        scrollLeft.value = taskContainer.value.scrollLeft; // 容器滚动位置
    }
}

function onTouchStart(e: TouchEvent) {
    isDragging.value = true;
    startX.value = e.touches[0].pageX; // 触摸起始位置
    if (taskContainer.value) {
        scrollLeft.value = taskContainer.value.scrollLeft;
    }
}

function onMouseMove(e: MouseEvent) {
    if (!isDragging.value || !taskContainer.value) return;
    const x = e.pageX; // 鼠标当前位置
    const walk = (x - startX.value) * 1.5; // 滑动距离
    taskContainer.value.scrollLeft = scrollLeft.value - walk;
}

function onTouchMove(e: TouchEvent) {
    if (!isDragging.value || !taskContainer.value) return;
    const x = e.touches[0].pageX; // 触摸当前位置
    const walk = (x - startX.value) * 1.5;
    taskContainer.value.scrollLeft = scrollLeft.value - walk;
}

function onMouseUp() {
    isDragging.value = false; // 停止拖拽
}

// 选择作业
// eslint-disable-next-line
function changeTask(task: any, id: number) {
    selectedTaskId.value = id; // 更新选中状态
    taskInfoStore.choosedId = id; // 更新作业id
    taskInfoStore.setTaskInfo(task); // 更新作业信息
    EventBus.emit('openTaskDetailed')
}

// 下一次作业
function nextTasks() {
    ElMessage({
        duration: 500,
        message: '切换至下一次作业.',
        type: 'success',
    })
}

// 历史作业
function historyTasks() {
    ElMessage({
        duration: 500,
        message: '切换至历史作业.',
        type: 'success',
    })
}

</script>
<style lang="less" scoped>
.task {
    display: flex;
    justify-content: space-between;
    align-items: center;
    height: 55px;
    // width: 100%;
    box-sizing: border-box;
    margin: 0 2%;

    .left {
        width: 62%;
        display: flex;
        justify-content: start;
        align-items: center;

        .task-container {
            border-right: 1px solid #ccc;
            display: flex;
            overflow-y: auto;
            justify-content: start;
            align-items: center;
            overflow: hidden;


            .task-item {
                align-items: center;

                #task {
                    width: 40px;
                    height: 40px;
                    margin-right: 10px;
                    background-repeat: no-repeat;
                    border: none;
                    border-radius: 10px;
                    background-image: url('@/assets/image/task-icon2.png');

                }

                .unChoose {
                    background-position: -5px -265px;
                }

                .choose {
                    background-position: -265px -213px;
                }
            }
        }

        /* 保持子元素相对于父容器 */

    }

    .right {
        margin-right: 5%;
    }

}

/* 初始和结束状态 */
.slide-down-enter-from {
    transform: translateY(-100%);
    /* 初始状态移出屏幕（刚好在父容器上方） */
    opacity: 0;
    /* 可选：让元素淡入淡出 */
}

.slide-down-enter-to {
    transform: translateY(0);
    /* 完全显示在父容器位置 */
    opacity: 1;
}

.slide-down-leave-to {
    transform: translateY(-100%);

    opacity: 0;
    /* 可选：让元素淡入淡出 */

}

.slide-down-leave-from {
    transform: translateY(0);
    /* 完全显示在父容器位置 */
    opacity: 0;
}

/* 动画的过渡效果 */
.slide-down-enter-active,
.slide-down-leave-active {
    transition: transform 0.3s ease, opacity 0.3s ease;
}
</style>