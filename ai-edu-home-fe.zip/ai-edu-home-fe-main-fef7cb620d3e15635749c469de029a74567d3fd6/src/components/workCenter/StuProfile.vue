<template>
    <div class="container">
        <!-- 左侧功能部分 -->
        <div class="left">
            <div class="menu-item" v-for="(item, index) in menuItems" :key="index"
                :class="{ selected: selectedMenu === index }" @click="selectMenu(index)">
                <!-- 使用背景图片代替 img -->
                <div class="menu-icon" :class="{ active: selectedMenu === index }" :style="{
                    backgroundPosition: selectedMenu === index ? item.activePosition : item.inactivePosition,
                }"></div>
                <!-- 文本部分 -->
                <span>{{ item.label }}</span>
            </div>
        </div>


        <!-- 右侧作业展示区域 -->
        <div class="right">
            <!-- 任务 -->
            <div class="Task" v-if="selectedMenu == 0">
                <img src="@/assets/image/暂无任务.png" alt="">
            </div>

            <!-- 作业 -->
            <div class="Operation" v-if="selectedMenu == 1">
                <!-- 筛选按钮 -->
                <div class="filter">
                    <p>筛选</p>
                    <div v-for="(filter, index) in filters" :key="index" class="filter-item">
                        <input type="radio" :id="'filter-' + index" :value="filter" v-model="selectedFilter" />
                        <label :for="'filter-' + index">
                            {{ filter }}
                        </label>
                    </div>
                </div>

                <!-- 作业列表 -->
                <div class="tasks-list">
                    <div class="task-item" v-for="(task, index) in filteredTasks" :key="index">
                        <div class="details">
                            <div class="task-icon" :class="task.status === 'completed' ? 'completed' : 'pending'"></div>
                            <div class="task-details">
                                <div class="task-name">作业{{ task.id }}</div>
                                <div class="task-status">
                                    <span>
                                        {{ task.status === 'completed' ? '已完成' : '未完成' }}
                                    </span>
                                </div>
                            </div>
                        </div>

                        <div class="dialage">
                            <el-button :color="buttonColor" plain @click="openTaskDrawer(task)" class="return">
                                <el-icon>
                                    <List />
                                </el-icon>
                                作业详细
                            </el-button>

                        </div>
                    </div>
                </div>

                <!-- 作业抽屉 -->
                <topic-drawer :is-visible="taskDrawerVisible" :task="selectedTask" :show-footer="true"
                    @update:isVisible="taskDrawerVisible = $event">
                    <template #default="{ task }">
                        <wangEditor :task="task" />
                    </template>
                </topic-drawer>
            </div>


            <!-- 成绩 -->
            <div class="Score" v-if="selectedMenu == 2">
                <img src="@/assets/image/暂无成绩.png" alt="">
            </div>

            <!-- 学习记录 -->
            <div class="Record" v-if="selectedMenu == 3">
                <!-- 作业列表 -->
                <div class="record-list">
                    <div class="record-item" v-for="(record, index) in recordArray" :key="index">
                        <div class="detail">
                            <div class="record-icon"></div>
                            <div class="record-details">
                                <div class="record-language">代码语言:{{ record.language }}</div>
                                <div class="record-time">记录时间:{{ record.createdAt }}</div>
                            </div>
                        </div>
                        <div class="dialage">
                            <el-button :color="buttonColor" plain @click="openRecordDrawer(record)" class="return">
                                <el-icon>
                                    <List />
                                </el-icon>
                                记录详细
                            </el-button>

                        </div>
                    </div>
                </div>

                <!-- 学习记录抽屉 -->
                <record-drawer :is-visible="recordDrawerVisible" :record="selectedRecord"
                    @update:isVisible="recordDrawerVisible = $event">
                    <template #default="{ record }">
                        <p>代码:</p>
                        <pre>{{ record.code }}</pre>
                    </template>
                </record-drawer>

            </div>


        </div>
    </div>
</template>

<script setup>
import { ref, computed } from 'vue';
import { recordsByUserId } from '@/api/compileCode';
import { getAssignments } from '@/api/assignments';
import { useUserInfoStore } from '@/store/userInfoStore';
import { List } from '@element-plus/icons-vue'; // 引入图标
import TopicDrawer from '../drawer/TopicDrawer.vue';
import RecordDrawer from '../drawer/RecordDrawer.vue';
import WangEditor from '@/components/codeMirror/WangEditor.vue';


// 菜单项数据
const menuItems = ref([
    {
        label: '任务',
        activePosition: '0 -24px', // 激活状态图片的位置
        inactivePosition: '0px 0px', // 未激活状态图片的位置
    },
    {
        label: '作业',
        activePosition: '-144px -24px',
        inactivePosition: '-144px 0',
    },
    {
        label: '成绩',
        activePosition: '-168px -24px',
        inactivePosition: '-168px 0px',
    },
    {
        label: '提交记录',
        activePosition: '-336px -24px',
        inactivePosition: '-336px 0',
    },
]);

const userInfoStore = useUserInfoStore();
// 默认选中的菜单项索引
const selectedMenu = ref(0);

// 选中的筛选项
const selectedFilter = ref('全部');

// 可用的筛选项
const filters = ['全部', '已完成', '未完成'];
let buttonColor = ref('#626aef'); // 按钮颜色

// 作业数据
const tasks = ref([]);
// 作业数据
const recordArray = ref([]);


// 根据筛选条件过滤作业
const filteredTasks = computed(() => {
    if (selectedFilter.value === '已完成') {
        return tasks.value.filter(task => task.status === 'completed');
    } else if (selectedFilter.value === '未完成') {
        return tasks.value.filter(task => task.status === 'pending');
    }
    return tasks.value; // 全部任务
});

// 选择菜单项
const selectMenu = async (index) => {
    if (index === 1) {
        if (tasks.value.length == 0) {
            getTask()
        }
    }
    else if (index === 3) {
        if (recordArray.value.length == 0)
            getRecord()


    }
    selectedMenu.value = index;
};

// 获取作业
const getTask = async () => {
    // 获取作业
    const assignments = await getAssignments();
    tasks.value = assignments.data.data;

    // 如果recordArray为空，调用getRecord并等待它完成
    if (recordArray.value.length === 0) {
        await getRecord();  // 使用await确保getRecord完成后再继续
    }

    // 初始化任务状态
    const knowledgePointIds = new Set(recordArray.value.map(record => record.knowledgePointId));
    tasks.value.forEach(task => {
        task.status = knowledgePointIds.has(task.knowledgePointId) ? 'completed' : 'pending';
    });

    console.log('获取作业,初始化作业数据', tasks.value);
}

// 获取记录
const getRecord = async () => {
    // 获取学习记录
    const userId = userInfoStore.id;
    const res = await recordsByUserId(userId);
    recordArray.value = res.data.data.data;
    console.log('获取记录,学习记录数据:', recordArray.value);
}

//任务抽屉
const taskDrawerVisible = ref(false); // 控制抽屉的显示状态
const selectedTask = ref({});
// 选择筛选条件
const openTaskDrawer = (task) => {
    selectedTask.value = task;
    taskDrawerVisible.value = true; // 打开抽屉
};

//记录抽屉
const recordDrawerVisible = ref(false); // 控制抽屉的显示状态
const selectedRecord = ref({});
// 选择筛选条件
const openRecordDrawer = (record) => {
    selectedRecord.value = record;
    recordDrawerVisible.value = true; // 打开抽屉
};

</script>

<style lang="less" scoped>
.container {
    display: flex;
    height: 100%;
    width: 100%;
    color: var(--text-color);
}


.left {
    box-sizing: border-box;
    padding-top: 5%;
    width: 11%;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: start;
    background-color: var(--profile-background-color);

    .menu-item {
        box-sizing: border-box;
        padding-left: 20%;
        font-size: 14px;
        width: 100%;
        height: 55px;
        display: flex;
        align-items: center;
        // justify-content: center; 
        cursor: pointer;
        transition: background-color 0.3s ease;

        .menu-icon {
            width: 24px;
            height: 24px;
            background-image: url('@/assets/image/menu-icon.png');
            background-size: 1800%;
            /* 雪碧图路径 */
            background-repeat: no-repeat;
            transition: background-position 0.3s;
            margin-right: 6px;
            margin-top: -2px;
        }

        span {
            color: var(--text-color);
        }

        &.selected {
            background-color: var(--top-bottom-background-color);
            /* 天蓝色背景 */

            span {
                color: #1e90ff;
                /* 天蓝色文字 */
            }
        }
    }
}



.right {
    width: 90%;
    margin: 20px;
    padding: 20px;
    overflow-y: auto;
    /* 右侧有滚动条 */
    background-color: var(--cm-editor-background-color);
    // box-sizing: border-box;


}

.right::-webkit-scrollbar {
    width: 12px;
    height: 10px;
}

.right::-webkit-scrollbar-thumb {
    background-color: var(--scroller-thumb-color);
    border-radius: 8px;
    cursor: pointer;
}

.right::-webkit-scrollbar-thumb:hover {
    background-color: var(--scroller-hover-color);
    cursor: pointer;
}

.right::-webkit-scrollbar-track {
    background-color: var(--scroller-background-color);
    cursor: pointer;

}


.Operation {
    .filter {
        align-items: center;
        margin-bottom: 20px;
        display: flex;
        padding: 10px;
        border-radius: 5px;
        box-shadow: 0 2px 0px rgba(0, 0, 0, 0.1),
            2px 0px rgba(0, 0, 0, 0.1),
            0 -2px 0px rgba(0, 0, 0, 0.1);

        p {
            margin-right: 10px;
            color: #888;
        }

        .filter-item {
            margin-right: 20px;
        }
    }

    .filter button {
        margin-right: 10px;
        padding: 10px 20px;
        border: 1px solid #ddd;
        background-color: #fff;
        cursor: pointer;
        transition: background-color 0.3s;
    }

    .filter button.active {
        background-color: #add8e6;
        /* 天蓝色 */
    }

    .tasks-list {
        display: flex;
        flex-direction: column;
        gap: 15px;
    }

    .task-item {
        display: flex;
        align-items: center;
        justify-content: space-between;
        padding: 10px;
        background-color: var(--top-bottom-background-color);
        border-radius: 5px;
        box-shadow: 0 10px 5px rgba(0, 0, 0, 0.1);

        .details {
            display: flex;
            align-items: center;
            /* 图标和详情垂直居中对齐 */
        }

        .task-icon {
            border-radius: 8px;
            width: 84px;
            height: 84px;
            transform: scale(0.5);
            background-image: url('@/assets/image/task-icon.png');
        }

        .task-details {
            text-align: left;
            display: flex;
            flex-direction: column;
            /* 让语言和时间垂直排列 */

            .task-status {
                font-size: 14px;
                color: #888;
            }
        }

        .dialage {
            text-align: right;
            /* 靠右对齐 */
            margin-right: 20px;
        }

        .completed {
            background-position: -10px -530px;
        }

        .pending {
            background-position: -530px -426px;
        }

    }

}

.Record {
    .record-list {
        display: flex;
        flex-direction: column;
        gap: 15px;
    }

    .record-item {
        display: flex;
        align-items: center;
        justify-content: space-between;
        /* 左右对齐 */
        padding: 10px;
        background-color: var(--top-bottom-background-color);
        border-radius: 5px;
        box-shadow: 0 10px 5px rgba(0, 0, 0, 0.1);

        .detail {
            display: flex;
            align-items: center;
            /* 图标和详情垂直居中对齐 */
        }

        .record-icon {
            width: 84px;
            height: 84px;
            transform: scale(0.5);
            margin-right: 10px;
            /* 图标和详情之间的间距 */
            background-image: url('@/assets/image/学习记录.png');
            background-size: cover;
            background-repeat: no-repeat;
            flex-shrink: 0;
            /* 防止图标缩小 */
        }

        .record-details {
            text-align: left;
            display: flex;
            flex-direction: column;
            /* 让语言和时间垂直排列 */
        }

        .record-language,
        .record-time {
            margin: 2px 0;
            /* 每个文本项的上下间距 */
        }

        .dialage {
            text-align: right;
            /* 靠右对齐 */
            margin-right: 20px;
        }
    }
}
</style>