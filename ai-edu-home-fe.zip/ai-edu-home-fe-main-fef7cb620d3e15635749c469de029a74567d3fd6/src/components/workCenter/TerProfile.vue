<template>
    <div class="container">
        <!-- 左侧功能部分 -->
        <div class="left">
            <div class="menu-item" v-for="(item, index) in menuItems" :key="index"
                :class="{ selected: selectedMenu === index }" @click="selectMenu(index)">
                <!-- 使用背景图片代替 img -->
                <div class="menu-icon" :class="{ active: selectedMenu === index }" :style="{
                    backgroundPosition: selectedMenu === index ? item.activePosition : item.inactivePosition,
                }"></div>
                <!-- 文本部分 -->
                <span>{{ item.label }}</span>
            </div>
        </div>


        <!-- 右侧作业展示区域 -->
        <div class="right">
            <!-- 任务 -->
            <div class="Task" v-if="selectedMenu == 0">
                <img src="@/assets/image/暂无任务.png" alt="">
            </div>

            <!-- 作业 -->
            <div class="Operation" v-if="selectedMenu == 1">
                <div class="top">
                    <!-- 添加作业按钮 -->
                    <div class="addOperation">
                        <el-button plain :color="buttonColor" @click="addOperation">
                            <el-icon>
                                <CirclePlus />
                            </el-icon>
                            添加作业
                        </el-button>
                    </div>

                    <!-- 筛选按钮 -->
                    <div class="filter">
                        <p>全部</p>
                        <input type="radio" id="all" value="全部" v-model="selectedFilter" @change="loadAllTasks" />
                        <p>筛选:</p>
                        <el-input style="width: 150px" v-model="searchKnowId" placeholder="请输入知识点ID"></el-input>
                        <el-button class="search" plain :color="buttonColor" @click="searchId">
                            <el-icon>
                                <Search />
                            </el-icon>
                            查询作业
                        </el-button>
                    </div>
                </div>

                <!-- 作业列表 -->
                <div class="tasks-list">
                    <div class="task-item" v-for="(task, index) in filteredTasks" :key="index">
                        <div class="details">
                            <div class="task-icon pending"></div>
                            <div class="task-details">
                                <div class="task-name">作业{{ task.id }}</div>
                            </div>
                        </div>

                        <div class="dialage">
                            <el-button plain :color="buttonColor" @click="openTaskDrawer(task)" class="return">
                                <el-icon>
                                    <List />
                                </el-icon>
                                记录详细
                            </el-button>

                        </div>
                    </div>
                </div>

                <!-- 作业抽屉 -->
                <topic-drawer :is-visible="taskDrawerVisible" :task="selectedTask" :show-footer="true"
                    @update:isVisible="taskDrawerVisible = $event" @task-updated="getTask" :remark="'教师'">
                    <template #default="{ task }">
                        <p>要求:</p>
                        <p>{{ task.description }}</p>
                    </template>
                </topic-drawer>

            </div>

            <!-- 成绩 -->
            <div class="Score" v-if="selectedMenu == 2">
                <img src="@/assets/image/暂无成绩.png" alt="">
            </div>

            <!-- 学习记录 -->
            <div class="Record" v-if="selectedMenu == 3">
                <!-- 作业列表 -->
                <!-- <div class="record-list">
                    <div class="record-item" v-for="(record, index) in recordArray" :key="index">
                        <div class="detail">
                            <div class="record-icon"></div>
                            <div class="record-details">
                                <div class="record-language">代码语言:{{ record.language }}</div>
                                <div class="record-time">记录时间:{{ record.createdAt }}</div>
                            </div>
                        </div>
                        <div class="dialage">
                            <el-button :color="buttonColor" plain @click="openRecordDrawer(record)" class="return">
                                <el-icon>
                                    <List />
                                </el-icon>
                                记录详细
                            </el-button>
                            <record-drawer :is-visible="recordDrawerVisible && selectedRecord?.id === record.id"
                                :record="selectedRecord" @update:isVisible="recordDrawerVisible = $event">
                                <template #default="{ record }">
                                    <p>代码:</p>
                                    <pre>{{ record.code }}</pre>
                                </template>
                            </record-drawer>
                        </div>
                    </div>
                </div> -->

                <img src="@/assets/image/暂无学习记录.png" alt="">
            </div>

        </div>

        <!-- 遮罩层及表单的模态框 -->
        <el-dialog v-model="newTaskDrawerVisible" title="添加作业" :center="true" :width="'40%'" @close="resetForm">
            <!-- 表单内容 -->
            <el-form ref="taskFormRef" :model="taskForm" :rules="rules" label-width="100px">
                <!-- 作业名 -->
                <!-- <el-form-item label="作业名" prop="homeworkName">
                    <el-input v-model="taskForm.homeworkName" placeholder="请输入作业名"></el-input>
                </el-form-item> -->

                <!-- 知识点ID -->
                <el-form-item label="知识点ID" prop="knowledgePointId">
                    <el-input v-model="taskForm.knowledgePointId" placeholder="请输入知识点ID"></el-input>
                </el-form-item>

                <!-- 作业任务 -->
                <el-form-item label="作业任务" prop="description">
                    <el-input type="textarea" v-model="taskForm.description" placeholder="请输入作业任务" :rows="4"></el-input>
                </el-form-item>
            </el-form>

            <!-- 按钮 -->
            <template #footer>
                <el-button type="info" @click="confirmReset">重置</el-button>
                <el-button type="primary" @click="saveForm">发布</el-button>
            </template>
        </el-dialog>
    </div>
</template>

<script setup>
import { ref, onMounted } from 'vue';
import { getAssignments, postAssignments } from '@/api/assignments';
import { List, CirclePlus, Search } from '@element-plus/icons-vue'; // 引入图标
import TopicDrawer from '../drawer/TopicDrawer.vue';
import { ElMessageBox, ElMessage } from "element-plus";


// 菜单项数据
const menuItems = ref([
    {
        label: '所有任务',
        activePosition: '0 -24px', // 激活状态图片的位置
        inactivePosition: '0px 0px', // 未激活状态图片的位置
    },
    {
        label: '所有作业',
        activePosition: '-144px -24px',
        inactivePosition: '-144px 0',
    },
    {
        label: '学生成绩',
        activePosition: '-168px -24px',
        inactivePosition: '-168px 0px',
    },
    {
        label: '学生学习记录',
        activePosition: '-336px -24px',
        inactivePosition: '-336px 0',
    },
]);

// 默认选中的菜单项索引
const selectedMenu = ref(1);


// 可用的筛选项
let buttonColor = ref('#626aef'); // 按钮颜色

// 作业数据
const tasks = ref([]);
const filteredTasks = ref([]);
//作业表单
const taskForm = ref({
    // homeworkName: '',
    knowledgePointId: '',
    description: '',
});
// 知识点ID
const searchKnowId = ref('');
const taskFormRef = ref(); // 表单引用
const selectedFilter = ref('全部'); // 默认选中全部
// 表单验证规则
const rules = {
    // homeworkName: [{ required: true, message: "请输入作业名", trigger: "blur" }],
    knowledgePointId: [{ required: true, message: "请输入知识点ID", trigger: "blur" }],
    description: [{ required: true, message: "请输入作业任务", trigger: "blur" }],
}
// 选择菜单项
const selectMenu = async (index) => {
    selectedMenu.value = index;
};

onMounted(() => {
    getTask();
});

// 获取作业
const getTask = async () => {
    // 获取作业
    const assignments = await getAssignments();
    tasks.value = assignments.data.data;
    filteredTasks.value = tasks.value;
    console.log('获取作业,初始化作业数据', tasks.value);
}


//任务抽屉
const taskDrawerVisible = ref(false); // 控制抽屉的显示状态
const newTaskDrawerVisible = ref(false); // 控制抽屉的显示状态
const selectedTask = ref({});

// 打开新建作业抽屉
const openTaskDrawer = (task) => {
    selectedTask.value = task;
    taskDrawerVisible.value = true; // 打开抽屉
};

// 新建作业
const addOperation = () => {
    newTaskDrawerVisible.value = true; // 显示模态框
}

//查询作业通过知识点ID
const searchId = () => {
    if (searchKnowId.value) {
        filteredTasks.value = tasks.value.filter(task => task.knowledgePointId === searchKnowId.value);
        selectedFilter.value = '';
    } else {
        ElMessage({
            message: '未输入知识点ID',
            type: 'warning',
        })
    }

}

// 当点击 "全部" radio 按钮时，加载所有任务
const loadAllTasks = () => {
    if (selectedFilter.value === '全部') {
        filteredTasks.value = tasks.value;
    }
}

// 二次确认重置作业表单
const confirmReset = () => {
    ElMessageBox.confirm("确定要重置表单吗？", "提示", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning",
    })
        .then(() => {
            resetForm();
            ElMessage.success("表单已重置");
        })
        .catch(() => {
            ElMessage.info("已取消重置");
        });
}

// 重置作业表单
const resetForm = () => {
    taskFormRef.value.resetFields(); // 重置表单
}

// 保存作业表单
const saveForm = () => {
    taskFormRef.value.validate(async (valid) => {
        if (valid) {
            const res = await postAssignments(taskForm.value.description, taskForm.value.knowledgePointId);
            if (res.data.code === 200) {
                ElMessage.success("发布成功");
                getTask();
            } else {
                ElMessage.error(res.data.message);
            }
            newTaskDrawerVisible.value = false; // 关闭模态框
        } else {
            ElMessage.error("请填写完整的表单");
        }
    });
}


</script>

<style lang="less" scoped>
.container {
    display: flex;
    height: 100%;
    width: 100%;
    color: var(--text-color);
}


.left {
    box-sizing: border-box;
    padding-top: 5%;
    width: 11%;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: start;
    background-color: var(--profile-background-color);

    .menu-item {
        box-sizing: border-box;
        padding-left: 20%;
        font-size: 14px;
        width: 100%;
        height: 55px;
        display: flex;
        align-items: center;
        // justify-content: center; 
        cursor: pointer;
        transition: background-color 0.3s ease;

        .menu-icon {
            width: 24px;
            height: 24px;
            background-image: url('@/assets/image/menu-icon.png');
            background-size: 1800%;
            /* 雪碧图路径 */
            background-repeat: no-repeat;
            transition: background-position 0.3s;
            margin-right: 6px;
            margin-top: -2px;
        }

        span {
            color: var(--text-color);
        }

        &.selected {
            background-color: var(--top-bottom-background-color);
            /* 天蓝色背景 */

            span {
                color: #1e90ff;
                /* 天蓝色文字 */
            }
        }
    }
}




.right {
    width: 90%;
    margin: 20px;
    padding: 20px;
    overflow-y: auto;
    /* 右侧有滚动条 */
    background-color: var(--cm-editor-background-color);
    // box-sizing: border-box;


}

.right::-webkit-scrollbar {
    width: 12px;
    height: 10px;
}

.right::-webkit-scrollbar-thumb {
    background-color: var(--scroller-thumb-color);
    border-radius: 8px;
    cursor: pointer;
}

.right::-webkit-scrollbar-thumb:hover {
    background-color: var(--scroller-hover-color);
    cursor: pointer;
}

.right::-webkit-scrollbar-track {
    background-color: var(--scroller-background-color);
    cursor: pointer;

}


.Operation {
    .top {
        padding-left: 10px;
        margin-bottom: 20px;
        display: flex;
        justify-content: space-between;
        border-radius: 5px;
        box-shadow: 0 2px 0px rgba(0, 0, 0, 0.1),
            2px 0px rgba(0, 0, 0, 0.1),
            0 -2px 0px rgba(0, 0, 0, 0.1);

        .filter {
            align-items: center;
            display: flex;

            #all {
                margin-right: 30px;
            }

            p {
                margin-right: 10px;
                color: #888;
            }

            .search {
                margin-left: 20px;
                margin-right: 30px;
            }
        }

        .addOperation {
            align-items: center;
            display: flex;

            p {
                margin-right: 10px;
                color: #888;
            }

            .filter-item {
                margin-right: 20px;
            }
        }
    }


    .tasks-list {
        display: flex;
        flex-direction: column;
        gap: 15px;
    }

    .task-item {
        display: flex;
        align-items: center;
        justify-content: space-between;
        padding: 10px;
        background-color: var(--top-bottom-background-color);
        border-radius: 5px;
        box-shadow: 0 10px 5px rgba(0, 0, 0, 0.1);

        .details {
            display: flex;
            align-items: center;
            /* 图标和详情垂直居中对齐 */
        }

        .task-icon {
            border-radius: 8px;
            width: 84px;
            height: 84px;
            transform: scale(0.5);
            background-image: url('@/assets/image/task-icon.png');
        }

        .task-details {
            text-align: left;
            display: flex;
            flex-direction: column;
            /* 让语言和时间垂直排列 */

            .task-status {
                font-size: 14px;
                color: #888;
            }
        }

        .dialage {
            text-align: right;
            /* 靠右对齐 */
            margin-right: 20px;
        }

        .pending {
            background-position: -530px -426px;
        }
    }

}

.Record {
    .record-list {
        display: flex;
        flex-direction: column;
        gap: 15px;
    }

    .record-item {
        display: flex;
        align-items: center;
        justify-content: space-between;
        /* 左右对齐 */
        padding: 10px;
        background-color: var(--top-bottom-background-color);
        border-radius: 5px;
        box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);

        .detail {
            display: flex;
            align-items: center;
            /* 图标和详情垂直居中对齐 */
        }

        .record-icon {
            width: 84px;
            height: 84px;
            transform: scale(0.5);
            margin-right: 10px;
            /* 图标和详情之间的间距 */
            background-image: url('@/assets/image/学习记录.png');
            background-size: cover;
            background-repeat: no-repeat;
            flex-shrink: 0;
            /* 防止图标缩小 */
        }

        .record-details {
            text-align: left;
            display: flex;
            flex-direction: column;
            /* 让语言和时间垂直排列 */
        }

        .record-language,
        .record-time {
            margin: 2px 0;
            /* 每个文本项的上下间距 */
        }

        .dialage {
            text-align: right;
            /* 靠右对齐 */
            margin-right: 20px;
        }
    }
}
</style>