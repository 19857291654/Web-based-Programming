<template>
    <div class="drawer">
        <el-drawer :model-value="isVisible" direction="rtl" custom-class="full-height-drawer" @close="handleClose"
            size="40%">
            <template #header>
                <h2 class="drawer-title">提交记录</h2>
            </template>
            <div>
                <hr />
                <div class="introduce">
                    <div class="info">
                        <p>代码语言</p>
                        <p>{{ record.language }}</p>
                    </div>
                    <div class="info">
                        <p>记录时间</p>
                        <p>{{ record.createdAt }}</p>
                    </div>
                    <div class="info">
                        <p>作业ID</p>
                        <p>{{ record.knowledgePointId || 'NULL' }}</p>
                    </div>
                </div>

                <hr />
                <!-- 插槽，用于显示传递的数据 -->
                <slot :record="record" />
            </div>
        </el-drawer>
    </div>

</template>

<script lang="ts">
import { defineComponent } from "vue";

export default defineComponent({
    name: "RecordDrawer",
    props: {
        isVisible: {
            type: Boolean,
            required: true,
        },
        record: {
            type: [Object],
            default: () => null,
        },
    },
    emits: ["update:isVisible", "close"],
    methods: {
        handleClose() {
            this.$emit("close"); // 发出关闭事件
            this.$emit("update:isVisible", false); // 更新父组件状态
        },
    },  
});
</script>

<style scoped>
::v-deep .el-drawer {
    background-color: var(--cm-editor-background-color);
}

.drawer {
    text-align: left;
    color: var(--text-color);
}

.drawer-title {
    font-weight: bold;
    color: var(--text-color);
}

hr {
    color: var(--separator-background-color);
    ;
}

.introduce {
    padding: 0 5%;
    display: flex;
    /* 使用flexbox布局使两个 .info 元素水平排列 */
    gap: 20px;
    /* 设置两个 info 元素之间的间距 */
}

.info {
    display: flex;
    /* 使每个 info 内的元素垂直排列 */
    flex-direction: column;
    /* 让 p 标签在 info 内部上下分布 */
    justify-content: space-between;
    /* 在 p 标签之间分配空间 */
}

p {
    margin: 0;
    /* 去掉 p 标签默认的外边距 */
}
</style>