<template>
    <div class="drawer">
        <el-drawer :model-value="isVisible" direction="rtl" @close="handleClose" size="40%">
            <template #header>
                <h2 class="drawer-title">作业{{ task.id }}</h2>
            </template>
            <div>
                <hr />
                <div class="introduce">
                    <div class="info">
                        <p>知识点</p>
                        <p>数组</p>
                    </div>
                    <div class="info">
                        <p>难度</p>
                        <p>简单</p>
                    </div>
                    <div class="info">
                        <p>作业ID</p>
                        <p>{{ task.knowledgePointId }}</p>
                    </div>
                </div>

                <hr />

                <!-- 插槽，用于显示传递的数据 -->
                <slot :task="task" />
            </div>
            <template #footer v-if="showFooter">
                <div style="flex: auto">
                    <el-button v-if="remark === '教师'" :color="buttonColor" plain @click="changeTask">
                        修改此题
                    </el-button>
                    <el-button :color="buttonColor" plain @click="editTask">
                        编辑此题
                    </el-button>
                </div>
                <!-- 遮罩层及表单的模态框 -->
                <el-dialog v-model="taskDrawerVisible" title="修改作业" :center="true" :width="'40%'" @close="resetForm">
                    <!-- 表单内容 -->
                    <el-form ref="taskFormRef" :model="newTaskForm" :rules="rules" label-width="100px">
                        <!-- 作业名 -->
                        <!-- <el-form-item label="作业名" prop="homeworkName">
                    <el-input v-model="newTaskForm.homeworkName" placeholder="请输入作业名"></el-input>
                </el-form-item> -->

                        <!-- 知识点ID -->
                        <el-form-item label="知识点ID" prop="knowledgePointId">
                            <el-input v-model="newTaskForm.knowledgePointId" placeholder="请输入知识点ID"></el-input>
                        </el-form-item>

                        <!-- 作业任务 -->
                        <el-form-item label="作业任务" prop="description">
                            <el-input type="textarea" v-model="newTaskForm.description" placeholder="请输入作业任务"
                                :rows="4"></el-input>
                        </el-form-item>
                    </el-form>

                    <!-- 按钮 -->
                    <template #footer>
                        <el-button type="primary" @click="saveChange">确认修改</el-button>
                    </template>
                </el-dialog>
            </template>
        </el-drawer>
    </div>
</template>

<script lang="ts">
import { defineComponent } from "vue";
import router from "@/router";
import { useTaskInfoStore } from "@/store/taskInfoStore";
import { ElMessageBox, ElMessage } from "element-plus";
import { patchAssignments } from "@/api/assignments";
import type { FormInstance } from "element-plus";

export default defineComponent({
    name: "TopicDrawer",
    data() {
        return {
            buttonColor: "#626aef", // 按钮颜色
            taskDrawerVisible: false, // 控制新建任务抽屉的显示状态
            newTaskForm: {
                knowledgePointId: "",
                description: "",
            },
            oddTaskForm: {
                knowledgePointId: "",
                description: "",
            },
            rules: {
                knowledgePointId: [{ required: true, message: "请输入知识点ID", trigger: "blur" }],
                description: [{ required: true, message: "请输入作业任务", trigger: "blur" }],
            },
        };
    },
    props: {
        isVisible: {
            type: Boolean,
            required: true,
        },
        task: {
            type: Object,
            default: () => ({}),
        },
        showFooter: {
            type: Boolean,
            default: false,
        },
        remark: {
            type: String,
            default: "学生",
        },
    },
    emits: ["update:isVisible", "close", 'task-updated'],
    methods: {
        handleClose() {
            this.$emit("close"); // 发出关闭事件
            this.$emit("update:isVisible", false); // 更新父组件状态
        },
        changeTask() {
            // 初始化表单内容
            this.oddTaskForm.knowledgePointId = this.task.knowledgePointId || "";
            this.oddTaskForm.description = this.task.description || "";

            this.newTaskForm.knowledgePointId = this.task.knowledgePointId || "";
            this.newTaskForm.description = this.task.description || "";
            this.taskDrawerVisible = true; // 打开模态框
        },
        resetForm() {
            // 通过 this.$refs 获取表单的引用
            (this.$refs.taskFormRef as FormInstance)?.resetFields();
        },
        saveChange() {
            (this.$refs.taskFormRef as FormInstance)?.validate(async (valid: boolean) => {
                if (valid) {
                    try {
                        await ElMessageBox.confirm("确定要修改作业吗？", "提示", {
                            confirmButtonText: "确定",
                            cancelButtonText: "取消",
                            type: "warning",
                        });
                        if (this.newTaskForm.knowledgePointId === this.oddTaskForm.knowledgePointId && this.newTaskForm.description === this.oddTaskForm.description) {
                            ElMessage.info("未修改作业");
                            return;
                        }
                        // 调用 API 保存数据
                        const res = await patchAssignments(this.newTaskForm.description, this.newTaskForm.knowledgePointId);
                        console.log("修改作业结果:", res);

                        // 通知父组件更新任务数据
                        this.$emit("task-updated");

                        ElMessage.success("作业已修改");
                        this.taskDrawerVisible = false; // 关闭模态框
                        this.handleClose();
                    } catch (error) {
                        ElMessage.info("已取消修改作业");
                    }
                } else {
                    ElMessage.error("请填写完整的表单");
                }
            });
        },
        editTask() {
            const taskInfo = useTaskInfoStore();
            taskInfo.setTaskInfo(this.task);
            router.push("/");
        },
    },
});
</script>

<style scoped>
::v-deep .el-drawer {
    background-color: var(--cm-editor-background-color);
}

.drawer {
    text-align: left;
    color: var(--text-color);
}

.drawer-title {
    font-weight: bold;
    color: var(--text-color);
}

hr {
    color: var(--separator-background-color);
    ;
}

.introduce {
    padding: 0 5%;
    display: flex;
    /* 使用flexbox布局使两个 .info 元素水平排列 */
    gap: 20px;
    /* 设置两个 info 元素之间的间距 */
}

.info {
    display: flex;
    /* 使每个 info 内的元素垂直排列 */
    flex-direction: column;
    /* 让 p 标签在 info 内部上下分布 */
    justify-content: space-between;
    /* 在 p 标签之间分配空间 */
}

p {
    margin: 0;
    /* 去掉 p 标签默认的外边距 */
}
</style>