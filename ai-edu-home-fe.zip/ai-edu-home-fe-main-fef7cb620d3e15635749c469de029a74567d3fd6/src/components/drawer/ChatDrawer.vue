<template>
    <div class="chat-container" v-loading="chatAIStore.loading" element-loading-text="AI回复中..."
        element-loading-background="rgba(122, 122, 122, 0.8)">
        <div v-if="chatAIStore.chatResponse" class="output-box">
            <h3>ChatGPT 的回复:</h3>
            <p>{{ chatAIStore.chatResponse }}</p>
        </div>
        <!-- <div class="chat-box">
            <textarea v-model="userInput" placeholder="请输入您的问题..." class="input-box"></textarea>
            <el-button :disabled="loading" :color="buttonColor" plain @click="fetchResponse" class="send">
                <el-icon>
                    <Promotion />
                </el-icon>
                {{ loading ? '请求中...' : '发送' }}
            </el-button>
        </div> -->
    </div>
</template>

<script setup>
import { ref, onMounted } from 'vue';
import { fetchChatGPTResponse } from '../../utils/chatGpt';
// import { ElMessage } from 'element-plus';
// import { Promotion } from '@element-plus/icons-vue'; // 引入图标
import { useChatAIStore } from '@/store/chatAIStore';
import { useLanguageStore } from "@/store/languageStore";

const userInput = ref('当前c代码有什么问题?什么作用?');
// let buttonColor = ref('#282c34'); // 按钮颜色
const chatAIStore = useChatAIStore();
const languageStore = useLanguageStore();

const fetchResponse = async () => {

    chatAIStore.loading = true;

    try {
        const responseContent = await fetchChatGPTResponse([{ role: 'user', content: languageStore.code + userInput.value }]);
        chatAIStore.chatResponse = responseContent;
    } catch (err) {
        chatAIStore.chatResponse = err.message;
    } finally {
        chatAIStore.codeChanged = false;
        chatAIStore.loading = false;
    }
};


onMounted(() => {
    console.log('chatAIStore', chatAIStore.codeChanged);

    if (chatAIStore.codeChanged) {
        fetchResponse();
    }
});

</script>

<style lang="less" scoped>
.chat-container {
    height: 50%;
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 20px;
    padding: 20px;

    .chat-box {
        position: absolute;
        bottom: 0;
        width: 80%;
        gap: 10px;
        padding: 10px;
        border-radius: 1.5rem;
        background-color: var(--top-bottom-background-color);
        margin-bottom: 5px;

        .input-box {
            padding: 10px;
            box-sizing: border-box;
            width: 100%;
            height: 100px;
            font-size: 16px;
            border-radius: 5px;
            outline: none;
            resize: none;
            background-color: var(--top-bottom-background-color);
            color: var(--text-color);

        }

        .send {
            margin: 10px 0;
            position: relative;
            left: 40%;
        }
    }

    .output-box {
        width: 90%;
        height: 60vh;
        overflow-y: auto;
        padding: 20px;
        background-color: var(--top-bottom-background-color);
        color: var(--text-color);
        border-radius: 5px;

        h3 {
            margin-bottom: 10px;
            font-size: 20px;
        }

        p {
            font-size: 16px;
            white-space: pre-wrap;
        }
    }
}


.input-box,
.output-box {
    &::-webkit-scrollbar {
        width: 10px;
        height: 10px;
    }

    &::-webkit-scrollbar-thumb {
        background-color: var(--scroller-thumb-color);
        border-radius: 4px;
        cursor: pointer;
    }

    &::-webkit-scrollbar-thumb:hover {
        background-color: var(--scroller-hover-color);
        cursor: pointer;
    }

    &::-webkit-scrollbar-track {
        background-color: var(--scroller-background-color);
        cursor: pointer;
    }
}
</style>