<template>
    
    <div style="height: 55px; width: 100vw;">
        <transition name="slide-down">
            <div v-if="taskInfoStore.taskChoose" style="height: 55px; width: 100vw;">
                <taskNavigation></taskNavigation>
            </div>
        </transition>

        <!-- <transition name="fade"> -->
            <div v-if="!taskInfoStore.taskChoose" style="height: 55px; width: 100vw;">
                <avartNavigation>
                    <template #left>
                        <slot name="left"></slot>
                    </template>
                    <template #center-content>
                        <slot name="center-content"></slot>
                    </template>
                </avartNavigation>
            </div>
        <!-- </transition> -->
    </div>
</template>

<script lang="ts" setup>
import { onMounted } from 'vue';
import { useUserInfoStore } from '@/store/userInfoStore';
import { getAccountProfile } from '@/api/account';
import { useTaskInfoStore } from '@/store/taskInfoStore';

import avartNavigation from '@/components/TopNavigation/avartNavigation.vue';

import taskNavigation from './TopNavigation/taskNavigation.vue';

const userInfoStore = useUserInfoStore();
const taskInfoStore = useTaskInfoStore();

const authToken = localStorage.getItem('authToken');

onMounted(async () => {
    getAccountProfile(authToken as string).then(res => {
        console.log('getAccountProfile', res);
        const {
            avatar, createdAt, email, id, phone, qq, remark, status, updatedAt, username
        } = res.data.data;
        Object.assign(userInfoStore, { avatar, createdAt, email, id, phone, qq, remark, status, updatedAt, username });
    });

})
</script>

<style scoped lang="less">

.fade-enter-active,
.fade-leave-active {
    transition:transform 0.6s ease, opacity 0.6s ease;
}

    .fade-enter-from {
        opacity: 0;
    }

    .fade-leave-to {
        opacity: 0;
    }


/* 初始和结束状态 */
.slide-down-enter-from {
    transform: translateY(-100%);
    /* 初始状态移出屏幕（刚好在父容器上方） */
    opacity: 0;
    /* 可选：让元素淡入淡出 */
}

.slide-down-enter-to {
    transform: translateY(0);
    /* 完全显示在父容器位置 */
    opacity: 1;
}

.slide-down-leave-to {
    transform: translateY(-100%);

    opacity: 0;
    /* 可选：让元素淡入淡出 */

}

.slide-down-leave-from {
    transform: translateY(0);
    /* 完全显示在父容器位置 */
    opacity: 0;
}

/* 动画的过渡效果 */
.slide-down-enter-active
 {
    transition: transform 0.3s ease, opacity 0.3s ease;
}
.slide-down-leave-active{
    transition: transform 0.2s ease, opacity 0.2s ease;

}

</style>