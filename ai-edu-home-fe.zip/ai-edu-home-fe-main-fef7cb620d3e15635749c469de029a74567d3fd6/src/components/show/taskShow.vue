<template>

  <div class="show">

    <el-button class="side-button close-button" @click="handleClose">
      >>
    </el-button>
    <el-button class="side-button submit-button" @click="submitCode">
      提交
    </el-button>
    <div class="show-header">
      <h2 class="drawer-title">作业{{ task.id }}</h2>
      <el-button @click="handleClose" :color="buttonColor" plain>
        X关闭
      </el-button>
    </div>
    <div>
      <hr />
      <div class="show-introduce">
        <div class="info">
          <p>知识点</p>
          <p>数组</p>
        </div>
        <div class="info">
          <p>难度</p>
          <p>简单</p>
        </div>
        <div class="info">
          <p>作业ID</p>
          <p>{{ task.knowledgePointId }}</p>
        </div>
      </div>
      <hr />
      <slot :task="task" />
    </div>
  </div>
</template>

<script lang="ts">
import EventBus from "@/utils/eventBus";
import { ElMessage, ElLoading } from "element-plus";
import { defineComponent } from "vue";
import { commitTaskCode } from '@/api/compileCode'
import { useTaskInfoStore } from '@/store/taskInfoStore';
import { useLanguageStore } from '@/store/languageStore';

export default defineComponent({
  name: "taskShow",
  data() {
    return {
      buttonColor: "#626aef",
      taskDrawerVisible: false,
      taskInfoStore: useTaskInfoStore(),
      languageStore: useLanguageStore(),
    };
  },
  props: {
    task: {
      type: Object,
      default: () => ({}),
    },
  },
  methods: {
    handleClose() {
      EventBus.emit('closeTaskShow');
    },
    async submitCode() {
      const loading = ElLoading.service({
        lock: true,
        text: 'Loading',
        background: 'rgba(0, 0, 0, 0.7)',
      });

      const timeout = new Promise<null>((_, reject) =>
        setTimeout(() => reject(new Error('请求超时')), 10000) // 10 秒超时
      );

      try {
        const result = await Promise.race([commitTaskCode(this.task.id,
          this.languageStore.code,
          this.languageStore.language
        ), timeout]);
        console.log("🚀 ~ submitCode ~ result:", result)
        if (result?.data.data.error) {
          ElMessage.error('代码错误:' + result.data.data.error);
        } else {
          ElMessage.success('代码正确:' + result?.data.data.message);
        }
      } catch (error: any) {
        ElMessage.error('请求失败:' + (error as Error).message);
      } finally {
        loading.close();
      }
    }

  },
});
</script>

<style scoped>
.show {
  box-sizing: border-box;
  padding: 20px;
  position: absolute;
  top: 45px;
  /* bottom: 45px; */
  right: 0px;
  color: var(--text-color);
  background-color: var(--codeEdit-background-color);
  width: 40vw;
  height: calc(100vh - 90px);

  transition: all 0.3s ease;
  /* overflow: hidden; */
}

/* 关闭按钮 */
.side-button {
  position: absolute;
  left: -20px;
  /* 将按钮放置到左侧突出部分 */
  width: 30px;
  height: 30px;
  background-color: #ccc;
  /* 红色背景 */
  color: white;
  border-radius: 50%;
  /* 使按钮为圆形 */
  /* display: flex; */
  justify-content: center;
  align-items: center;
  cursor: pointer;
  font-size: 20px;
  z-index: 10;
}

.close-button {
  top: 0px;
}

.submit-button {
  top: 70px;
  left: -30px;
  font-size: 15px;
}

/* 关闭按钮 hover 效果 */
.side-button:hover {
  background-color: #626aef;
}


.show-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.drawer-title {
  font-weight: bold;
  color: var(--text-color);
}

.hr {
  color: var(--separator-background-color);
}

.show-introduce {
  padding: 0 5%;
  display: flex;
  gap: 20px;
}

.info {
  display: flex;
  flex-direction: column;
  justify-content: space-between;
}

p {
  margin: 0;
}
</style>