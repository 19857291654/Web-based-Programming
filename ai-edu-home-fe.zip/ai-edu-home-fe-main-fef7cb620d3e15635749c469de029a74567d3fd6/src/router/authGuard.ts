import { jwtDecode } from "jwt-decode";
import { Router } from "vue-router";
import { ElMessage } from 'element-plus'


export default function tokenGuard(router: Router) {
  router.beforeEach((to, from, next) => {
    const token = localStorage.getItem("authToken");
    if (to.meta.requiresAuth) {
      if (token) {
        try {
          // eslint-disable-next-line
          const decoded: any = jwtDecode(token);
          const expTime = decoded.exp * 1000;
          const currentTime = Date.now();

          if (currentTime > expTime) {
            console.log("Token已过期");
            localStorage.removeItem("authToken");
            ElMessage.error("Token已过期,请重新登录");
            next({ name: "login" });
          } else {
            console.log("Token未过期");
            next();
          }
        } catch (error) {
          console.error("Failed to decode token:", error);
          next({ name: "login" });
        }
      } else {
        console.log("No token found");
        next({ name: "login" });
      }
    } else {
      next();
    }
  });
}
