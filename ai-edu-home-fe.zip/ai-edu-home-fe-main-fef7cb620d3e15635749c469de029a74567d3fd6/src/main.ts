import { createApp } from 'vue'
import App from './App.vue'
import router from './router'
import { createPinia } from 'pinia';
import ElementPlus from "element-plus";
import 'element-plus/dist/index.css'; // 引入 Element Plus 的 CSS
import authGuard from './router/authGuard'; // 引入路由守卫

const pinia = createPinia();
const app = createApp(App);


// 注册 Element Plus
app.use(ElementPlus);
app.use(pinia).use(router)

authGuard(router); // 使用路由守卫
app.mount('#app')