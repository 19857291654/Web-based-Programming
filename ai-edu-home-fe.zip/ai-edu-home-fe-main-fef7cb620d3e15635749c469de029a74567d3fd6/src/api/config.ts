// apiConfig.js 或者你其他合适的配置文件

export const BASE_URL = 'http://101.37.71.106:7001/api';  // 定义接口前缀 线上
// export const BASE_URL = 'http://127.0.0.1:7001/api';  // 定义接口前缀 本地
