// src/api/auth.ts
import axios from 'axios';
import { BASE_URL } from './config';


// 编译
export const compileCode = (userId: string, knowledgePointId: string, language: string, code: string, inputValue: string) => {
  return axios.post(`${BASE_URL}/compile`,
    {
      userId,
      knowledgePointId,
      language,
      code,
      inputValue: inputValue
    },
    {
      headers: {
        'Authorization': `Bearer ${localStorage.getItem('authToken')}` // 在请求头中添加 Authorization Bearer token
      },
    }
  )
};


// 学生查看自己的作业
export const recordsByUserId = (userId: string) => {
  return axios.post(`${BASE_URL}/compile/records-by-user`,
    {
      userId,
    },
    {
      headers: {
        'Authorization': `Bearer ${localStorage.getItem('authToken')}` // 在请求头中添加 Authorization Bearer token
      },
    }
  )
};


// 学生查看自己的作业
export const commitTaskCode = (id: number,code:string,language:string) => {
  return axios.post(`${BASE_URL}/compile/run-and-compare`,
    {
      id,
      code,
      language
    },
    {
      headers: {
        'Authorization': `Bearer ${localStorage.getItem('authToken')}` // 在请求头中添加 Authorization Bearer token
      },
    }
  )
};
