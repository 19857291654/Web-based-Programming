// src/api/auth.ts
import axios from "axios";
import { BASE_URL } from './config';

// 获取账户资料接口
export const getAccountProfile = (token: string) => {
  return axios.get(`${BASE_URL}/account/profile`, {
    headers: {
      Authorization: `Bearer ${token}`, // 在请求头中添加 Authorization Bearer token
    },
  });
};

//账户登出
export const logout = (token: string) => {
  return axios.get(`${BASE_URL}/account/logout`, {
    headers: {
      Authorization: `Bearer ${token}`, // 在请求头中传递 Bearer token
    },
  });
};
