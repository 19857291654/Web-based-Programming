// src/api/auth.ts
import axios from 'axios';
import { BASE_URL } from './config';


// 登录接口
export const login = (phone: string, password: string, captchaId: string, verifyCode: string) => {
  return axios.post(`${BASE_URL}/auth/login`, {
    phone,
    password,
    captchaId,
    verifyCode,
  });
};

// 注册接口
export const register = (username: string, password: string, phone: string) => {
  return axios.post(`${BASE_URL}/auth/register`, {
    username,
    password,
    phone,
    lang: "en"
  });
};

// 验证码接口
export const captcha = () => {
  return axios.get(`${BASE_URL}/auth/captcha/img`);
};

