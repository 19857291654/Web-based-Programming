// src/api/auth.ts
import axios from "axios";
import { BASE_URL } from './config';

// 获取所有作业
export const getAssignments = () => {
    return axios.get(`${BASE_URL}/assignments`, {
        headers: {
            'Authorization': `Bearer ${localStorage.getItem('authToken')}` // 在请求头中添加 Authorization Bearer token
        },
    });
};

// 发布新作业
export const postAssignments = (description: string, knowledgePointId: string) => {
    return axios.post(`${BASE_URL}/assignments`,
        {
            description,
            knowledgePointId
        },
        {
            headers: {
                'Authorization': `Bearer ${localStorage.getItem('authToken')}` // 在请求头中添加 Authorization Bearer token
            }
        }
    );
};

export const patchAssignments = (description: string, knowledgePointId: string) => {
    return axios.patch(`${BASE_URL}/assignments/2`,
        {
            description,
            knowledgePointId
        },
        {
            headers: {
                'Authorization': `Bearer ${localStorage.getItem('authToken')}` // 在请求头中添加 Authorization Bearer token
            }
        }
    );
};
