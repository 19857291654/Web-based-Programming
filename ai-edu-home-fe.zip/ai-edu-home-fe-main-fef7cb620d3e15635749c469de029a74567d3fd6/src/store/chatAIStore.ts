import { defineStore } from "pinia";

export const useChatAIStore = defineStore("chatAI", {
    state: () => ({
        loading: false,
        codeChanged: false,
        chatResponse: "此段代码没有问题，这段 C 代码的作用是输出 'Hello, World!' 字符串到屏幕。",
    }),
});
