import { defineStore } from "pinia";

export const useLanguageStore = defineStore("language", {
  state: () => ({
    theme:'dark',
    code: "",
    language: "C",
    cCode: `#include <stdio.h>
int main()
{
   /*  Write C code in this online editor and run it. */
   printf("Hello, World! \\n");
   
   return 0;
}`,

    cppCode: `#include <iostream>
using namespace std;

int main()
{
   cout << "Hello World";
   return 0;
}`,

    pythonCode: `# Write Python 3 code in this online editor and run it.
print("Hello, World!");`,
  }),
});
