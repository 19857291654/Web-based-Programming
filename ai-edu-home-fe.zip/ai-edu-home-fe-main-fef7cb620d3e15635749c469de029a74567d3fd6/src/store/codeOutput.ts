import { defineStore } from "pinia";

export const useCodeOutputStore = defineStore("codeOutput", {
    state: () => ({
        input:'',
        defaultOutput: "Hello, World!",
        compileOutput: "",
        runOutput:'',
    }),
    actions:{
        reset(){
            this.input = '';
            this.defaultOutput = "Hello, World!";
            this.compileOutput = "";
            this.runOutput = '';
        }
    }
})