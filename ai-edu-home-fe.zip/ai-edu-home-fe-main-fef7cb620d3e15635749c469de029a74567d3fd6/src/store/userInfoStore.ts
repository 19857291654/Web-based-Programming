import { defineStore } from "pinia";

export const useUserInfoStore = defineStore("userInfo", {
  state: () => ({
    avatar:'',
    createdAt: '',
    email:'',
    id: '',
    phone:'',
    qq:'',
    remark:'',
    status: '',
    updatedAt: '',
    username: '',
  }),
});
