import { defineStore } from "pinia";

export const useTaskInfoStore = defineStore("taskInfo", {
  state: () => ({
    taskChoose: false,
    choosedId: -1,
    description: '',
    editorContent:'',
    id: -1,
    knowledgePointId: ''
  }),
  actions: {
    // eslint-disable-next-line
    setTaskInfo(taskInfo: any) {
      this.description = taskInfo.description;
      this.editorContent = taskInfo.editorContent;
      this.id = taskInfo.id;
      this.knowledgePointId = taskInfo.knowledgePointId;
    },
    clearTaskInfo() {
      this.description = '';
      this.id = -1;
      this.knowledgePointId = '';
    }
  }
});
