<template>
    <div class="login-container">
        <h1 class="login-title" style="margin-left: 80px;">欢迎登录</h1>
        
        <!-- 表单部分 -->
        <el-form size="large" :model="form" ref="formRef" label-width="100px" class="loginForm" @submit.prevent="onSubmit">
            <!-- 手机号 -->
            <el-form-item label="手机号" prop="phone" :rules="phoneRules">
                <el-input v-model="form.phone" placeholder="请输入手机号" />
            </el-form-item>

            <!-- 密码 -->
            <el-form-item label="密码" prop="password" :rules="passwordRules">
                <el-input v-model="form.password" placeholder="请输入密码" :type="addPassFlag ? 'text' : 'password'">
                    <template #suffix>
                        <span @click="addPassFlag = !addPassFlag">
                            <el-icon v-if="addPassFlag" style="cursor: pointer;">
                                <View />
                            </el-icon>
                            <el-icon v-else style="cursor: pointer;">
                                <Hide />
                            </el-icon>
                        </span>
                    </template>
                </el-input>
            </el-form-item>

            <!-- 验证码 -->
            <el-form-item label="验证码" prop="verifyCode" :rules="captchaRules">
                <div class="captcha-container">
                    <!-- 输入框部分 -->
                    <el-input v-model="form.verifyCode" placeholder="请输入验证码" />
                    <div class="captcha-img-container">
                        <img :src="captchaImg" alt="验证码" @click="getCaptcha" class="captcha-img"
                            style="height: 60px; cursor: pointer;" />
                    </div>
                </div>
            </el-form-item>

            <!-- 登录按钮 -->
            <el-form-item>
                <el-button  :color="buttonColor" plain :loading="loading" :disabled="loading" type="primary" size="large"
                    native-type="submit" block style="width: 100px;margin-left: 65px;">
                    <el-icon>
                        <Avatar />
                    </el-icon>
                    登录
                </el-button>
            </el-form-item>
        </el-form>

        <!-- 注册链接 -->
        <div class="register-link" style="margin-left: 90px;">
            <el-link type="primary" @click="goToRegister">没有账号？点击注册</el-link>
        </div>
    </div>
</template>

<script lang="ts" setup>
import { ref, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import { ElForm, ElInput, ElButton, ElLink, ElMessage, ElFormItem } from 'element-plus'
import { View, Hide, Avatar } from '@element-plus/icons-vue'
import { login, captcha } from '@/api/auth';

onMounted(() => {
    const authToken = localStorage.getItem('authToken')
    if (authToken) {
        router.push('/')
        ElMessage.success('用户已登录');
    }
    // 初始化时请求验证码
    getCaptcha()
})

let buttonColor = ref('#626aef'); // 按钮颜色
const loading = ref(false); // 控制按钮加载状态




// 表单模型
const form = ref({
    phone: '15792562781',  // 改为手机号
    password: 'Admin123',
    verifyCode: '',
    captchaId: '', // 验证码的 ID
})
// 引入路由实例
const router = useRouter()

// 验证码图片的 base64 字符串
const captchaImg = ref('')
const formRef = ref<InstanceType<typeof ElForm> | null>(null)

const addPassFlag = ref(false)//图标显示标识

// 表单校验规则
const phoneRules = [
    { required: true, message: '请输入手机号', trigger: 'blur' },
    { pattern: /^1[3-9]\d{9}$/, message: '手机号格式不正确', trigger: 'blur' }
]

const passwordRules = [
    { required: true, message: '请输入密码', trigger: 'blur' },
]

const captchaRules = [
    { required: true, message: '请输入验证码', trigger: 'blur' },
    { min: 4, max: 4, message: '验证码必须是4位', trigger: 'blur' },
    { pattern: /^[A-Za-z0-9]{4}$/, message: '验证码格式不正确,必须是4个字母或数字', trigger: 'blur' }
]

// 请求验证码   
const getCaptcha = async () => {
    try {
        const response = await captcha()
        const { img, id } = response.data.data
        captchaImg.value = img // 设置图片
        form.value.captchaId = id // 保存验证码的 ID
        console.log(id);

    } catch (error) {
        ElMessage.error('获取验证码失败，请稍后重试')
    }
}

// 提交表单
const onSubmit = async () => {
    const Form = formRef.value
    if (!Form) return
    // validate方法会返回一个 Promise，如果验证通过，执行登录逻辑，否则阻止提交
    Form.validate(async (valid: boolean) => {
        if (valid) {
            // 如果表单验证通过，可以执行登录逻辑
            console.log('表单验证通过，执行登录');
            loading.value = true

            try {
                const response = await login(form.value.phone, form.value.password, form.value.captchaId, form.value.verifyCode);
                console.log(form.value.captchaId);

                console.log(response);
                if (response.data) {
                    if (response.data.code === 200) {
                        const token = response.data.data.token;
                        localStorage.setItem('authToken', token);  // 将 token 存储在 localStorage
                        ElMessage.success('登录成功');
                        router.push('/');  // 跳转到首页
                    } else {
                        ElMessage.error(response.data.message);
                        getCaptcha()
                    }
                }
            } catch (error) {
                ElMessage.error('登录失败');
                getCaptcha()

            } finally {
                loading.value = false
            }

        } else {
            // 如果表单验证不通过，阻止表单提交并提示错误
            console.log('表单验证失败');
            ElMessage.error('请先完善表单');
            return;
        }
    });
};

// 跳转到注册页面
const goToRegister = () => {
    router.push('/register')
}

</script>

<style scoped lang="less">
.login-container {
    font-size: 16px;
    display: flex;
    flex-direction: column;
    width: 100vw;
    height: 100vh;
    margin: 0 auto;
    padding: 40px;
    background-color: rgb(218, 227, 234);
    box-sizing: border-box;
}

.login-title {
    flex: 1;
    text-align: center;
    // margin-bottom: 5%;
}

.loginForm {
    font-size: 20px;
    flex: 8;
    width: 360px;
    margin: 20px auto;
}

.captcha-container {
    display: flex;
    align-items: center;
    justify-content: space-between;

    .captcha-img-container {
        margin-left: 10px;
        /* Make some space between the input and image */
    }

    .captcha-img {
        cursor: pointer;
        vertical-align: middle;
        /* Align the image with input */
    }
}

.register-link {
    flex: 1;
    text-align: center;
    margin-top: 20px;
    user-select: none;
}

::v-deep .el-form-item__label {
    font-size: 20px;
    user-select: none;
    /* 禁用选择 */
    pointer-events: none;
    /* 禁止鼠标事件 */
}

::v-deep .el-form-item__error {
    user-select: none;
    /* 禁用选择 */
    pointer-events: none;
    /* 禁止鼠标事件 */
}
</style>
