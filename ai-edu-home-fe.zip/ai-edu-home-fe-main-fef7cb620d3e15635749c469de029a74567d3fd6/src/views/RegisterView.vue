<template>
    <div class="register-container">
        <h1 class="register-title" style="margin-left: 80px;">用户注册</h1>

        <!-- 表单部分 -->
        <el-form size="large" :model="form" ref="formRef" label-width="100px" class="registerForm" @submit.prevent="onSubmit">
            <!-- 姓名 -->
            <el-form-item label="姓名" prop="name" :rules="nameRules">
                <el-input v-model="form.name" placeholder="请输入姓名" />
            </el-form-item>

            <!-- 父母手机号 -->
            <el-form-item label="手机号" prop="parentPhone" :rules="parentPhoneRules">
                <el-input v-model="form.parentPhone" placeholder="请输入父母手机号" />
            </el-form-item>

            <!-- 密码 -->
            <el-form-item label="密码" prop="password" :rules="passwordRules">
                <el-input v-model="form.password" placeholder="请输入密码" :type="showPassword ? 'text' : 'password'">
                    <template #suffix>
                        <span @click="showPassword = !showPassword">
                            <el-icon v-if="showPassword" style="cursor: pointer;">
                                <View />
                            </el-icon>
                            <el-icon v-else style="cursor: pointer;">
                                <Hide />
                            </el-icon>
                        </span>
                    </template>
                </el-input>
            </el-form-item>

            <!-- 注册按钮 -->
            <el-form-item>
                <el-button :color="buttonColor" plain :loading="loading" :disabled="loading" type="primary"
                    native-type="submit" block style="width: 100px;margin-left: 45px;">
                    <el-icon><Promotion /></el-icon>
                    注册
                </el-button>
            </el-form-item>
        </el-form>

        <!-- 登录链接 -->
        <div class="login-link" style="margin-left: 90px;">
            <el-link type="primary" @click="goToLogin">已有账号？点击登录</el-link>
        </div>
    </div>
</template>

<script lang="ts" setup>
import { onMounted, ref } from 'vue'
import { useRouter } from 'vue-router'
import { ElMessage, ElForm, ElFormItem, ElInput, ElButton, ElLink } from 'element-plus'
import { View, Hide,Promotion } from '@element-plus/icons-vue'
import { register } from '@/api/auth'

// 路由实例
const router = useRouter()

let buttonColor = ref('#626aef'); // 按钮颜色
const loading = ref(false); // 控制按钮加载状态

// 表单模型
const form = ref({
    name: '',
    parentPhone: '',
    password: '',
    avatar: '',
})

// 密码可见性切换
const showPassword = ref(false)

// 表单引用
const formRef = ref<InstanceType<typeof ElForm> | null>(null)

// 表单校验规则
const nameRules = [
    { required: true, message: '请输入姓名', trigger: 'blur' },
]

const parentPhoneRules = [
    { required: true, message: '请输入父母手机号', trigger: 'blur' },
    { pattern: /^1[3-9]\d{9}$/, message: '手机号格式不正确', trigger: 'blur' },
]

const passwordRules = [
    { required: true, message: '请输入密码', trigger: 'blur' },
    { min: 6, max: 18, message: '密码长度需在6到18个字符之间', trigger: 'blur' },
    { pattern: /^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d]{6,18}$/, message: '密码必须包含字母和数字', trigger: 'blur' },
]


onMounted(() => {
    const authToken = localStorage.getItem('authToken')
    if (authToken) {
        router.push('/')
        ElMessage.success('用户已登录');
    }
    // 初始化时请求验证码
})


// 表单提交
const onSubmit = async () => {
    const Form = formRef.value
    if (!Form) return

    Form.validate(async (valid: boolean) => {
        if (valid) {
            // 如果表单验证通过，可以执行登录逻辑
            console.log('表单验证通过，执行登录');
            loading.value = true
            try {
                const response = await register(form.value.name, form.value.password, form.value.parentPhone)
                if (response.data.code === 200) {
                    ElMessage.success('注册成功')
                    router.push('/login') // 跳转到登录页面
                } else {
                    ElMessage.error(response.data.message)
                }
            } catch (error) {
                ElMessage.error('注册失败，请稍后重试')
            }   finally {
                loading.value = false
            }
        } else {
            ElMessage.error('请完善表单')
        }
    })
}

// 跳转到登录页面
const goToLogin = () => {
    router.push('/login')
}
</script>

<style scoped lang="less">
.register-container {
    display: flex;
    flex-direction: column;
    width: 100vw;
    height: 100vh;
    margin: 0 auto;
    padding: 40px;
    background-color: rgb(218, 227, 234);
    box-sizing: border-box;
}

.register-title {
    flex: 1;
    text-align: center;
}

.registerForm {
    flex: 8;
    width: 300px;
    margin: 20px auto;
}

.avatar-uploader {
    .avatar-placeholder {
        font-size: 28px;
        color: #ccc;
    }

    .avatar-preview {
        width: 100%;
        height: 100%;
    }
}

.login-link {
    flex: 1;
    text-align: center;
    margin-top: 20px;
    user-select: none;
}

::v-deep .el-form-item__label {
    font-size: 20px;
    user-select: none;
    /* 禁用选择 */
    pointer-events: none;
    /* 禁止鼠标事件 */
}

::v-deep .el-form-item__error {
    user-select: none;
    /* 禁用选择 */
    pointer-events: none;
    /* 禁止鼠标事件 */
}
</style>
