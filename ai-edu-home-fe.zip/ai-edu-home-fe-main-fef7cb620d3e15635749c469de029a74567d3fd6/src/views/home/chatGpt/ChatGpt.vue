<template>
    <div id="chatGPT" :data-theme="(languageStore.theme == 'light') ? 'light' : 'dark'">
      <ChatGPT />
    </div>
  </template>
  
  <script setup>
  import ChatGPT from '@/components/chatGpt/ChatGPT.vue';
  import { useLanguageStore } from '@/store/languageStore';

  const languageStore = useLanguageStore();
  </script>
  
  <style>

  </style>
  