<template>
    <div class="profile" :data-theme="(languageStore.theme == 'light') ? 'light' : 'dark'">
        <div class="top-navigation-bar">
            <TopNavigation>
                <!-- 左侧插槽 -->
                <template #left>
                    <el-button :color="buttonColor" plain @click="goToHome">
                        <el-icon>
                            <HomeFilled />
                        </el-icon>
                        返回
                    </el-button>
                </template>
                <template #center-content>
                    <span>学习中心</span>
                </template>
            </TopNavigation>
        </div>
        <div class="content" >
            <StuProfile></StuProfile>
        </div>
    </div>
</template>

<script lang="ts" setup>
import TopNavigation from '@/components/TopNavigation.vue';
import StuProfile from '@/components/workCenter/StuProfile.vue';
import { useLanguageStore } from '@/store/languageStore';
import { useUserInfoStore } from '@/store/userInfoStore';
import { useRouter } from "vue-router";
import { ref } from 'vue';
import { HomeFilled } from '@element-plus/icons-vue'; // 引入图标


// 在这里可以定义响应式变量、计算属性等
const router = useRouter();
const languageStore = useLanguageStore();
let buttonColor = ref('#626aef'); // 按钮颜色


// 返回首页逻辑
const goToHome = () => {
    router.push("/");
};
</script>

<style lang="less" scoped>
body {
    border: 0;
    padding: 0;
}

.profile {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    height: 100vh;
    width: 100vw;
    background-color: var(--compiler-background-color);
    // overflow: hidden;
}

.top-navigation-bar {
    height: 55px;
    width: 100vw;
    background-color: var(--top-bottom-background-color);
}

.content {
    width: 100%;
    height: calc(100vh - 55px);
    display: flex;
    justify-content: center;
    align-items: center;
    background-color: var(--compiler-background-color);
}
</style>