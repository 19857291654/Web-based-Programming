<template>
  <div class="compiler" :data-theme="(languageStore.theme == 'light') ? 'light' : 'dark'">
    <div class="top-navigation-bar">
      <TopNavigation>
        <template #left>
          <span>小码编程平台</span>
        </template>
        <template #center-content>
          <span></span>
        </template>
      </TopNavigation>
    </div>
    <div class="center-code-area">
      <CodeEdit></CodeEdit>
    </div>
    <div class="bottom-other-area">
      本系统由湖州学院计算机系陈老师团队研发设计
    </div>
  </div>
</template>

<script lang="ts">
import { defineComponent } from 'vue';
import CodeEdit from '@/components/codeMirror/CodeEdit.vue'
import TopNavigation from '@/components/TopNavigation.vue';
import { useLanguageStore } from '@/store/languageStore';

export default defineComponent({
  name: 'HomeView',
  components: {
    CodeEdit,
    TopNavigation,
  },
  setup() {
    // 在这里可以定义响应式变量、计算属性等
    // const message = ref('Hello from HomeView');
    const languageStore = useLanguageStore();

    return {
      languageStore
    };
  },
});
</script>

<style lang="less">
body {
  border: 0;
  padding: 0;
}

.compiler {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  height: 100vh;
  width: 100vw;
  background-color: var(--compiler-background-color);
  overflow: hidden;
}

.top-navigation-bar {
  height: 55px;
  width: 100vw;
  background-color: var(--top-bottom-background-color);
}

.center-code-area {
  height: calc(100vh - 90px);
  width: 98vw;
  padding: 2% 0%;
  background-color: var(--compiler-background-color);
  box-sizing: border-box;
  /* 包括内边距和边框在内的总宽度 */
}

.bottom-other-area {
  flex-direction: column;
  justify-content: center;
  display: flex;

  color: #999;
  height: 45px;
  width: 100vw;
  background-color: var(--top-bottom-background-color);
}
</style>