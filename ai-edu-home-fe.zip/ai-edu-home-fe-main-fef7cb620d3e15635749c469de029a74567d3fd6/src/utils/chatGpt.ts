import axios from 'axios';

const apiKey = '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'; 
export const fetchChatGPTResponse = async (messages: Array<{ role: string, content: string }>) => {
  const apiUrl = 'https://api.openai.com/v1/chat/completions';

  try {
    const res = await axios.post(
      apiUrl,
      {
        model: 'gpt-3.5-turbo',
        messages: messages,
      },
      {
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${apiKey}`,
        },
      }
    );

    return res.data.choices[0].message.content;
  } catch (err) {
    console.error(err);
    throw new Error('请求失败，请检查您的网络或API Key配置！');
  }
};