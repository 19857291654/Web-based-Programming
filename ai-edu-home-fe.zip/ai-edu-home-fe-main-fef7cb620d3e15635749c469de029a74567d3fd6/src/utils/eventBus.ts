// src/utils/eventBus.ts
import mitt from 'mitt';

const EventBus = mitt();
export default EventBus;
