// src/api.js
import axios from "axios";

const BASE_URL = "http://101.37.71.106:7001/api"; // 基础 URL

// 封装的 POST 请求函数
export const compileCode = async (code: string,inputValue:string) => {
  console.log(inputValue);
  
  try {
    const response = await axios.post(
      `${BASE_URL}/compile`,
      {
        code,
        inputValue:inputValue
      },
      {
        headers: {
          'Authorization': "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1aWQiOjEsInB2IjoxLCJyb2xlcyI6WyJhZG1pbiJdLCJpYXQiOjE3MzEzOTQ0OTAsImV4cCI6MTczMTQ4MDg5MH0.nsKOUYWmiUX6YiHRUfZVi1LSkG-kSPWa5eFg5L7OMGw", // 如果需要授权
        },
      }
    );
    return response.data; // 返回响应数据
  } catch (error) {
    console.error("请求失败:", error);
    throw error; // 抛出错误以便外部处理
  }
};
