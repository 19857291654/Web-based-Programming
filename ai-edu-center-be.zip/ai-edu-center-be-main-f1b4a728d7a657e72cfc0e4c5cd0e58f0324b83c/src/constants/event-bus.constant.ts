export enum EventBusEvents {
  TokenExpired = 'token.expired',
  SystemException = 'system.exception',
}
