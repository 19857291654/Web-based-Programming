export const SYS_TASK_QUEUE_NAME = 'system:sys-task'
export const SYS_TASK_QUEUE_PREFIX = 'system:sys:task'
