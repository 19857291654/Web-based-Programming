import { Injectable, NotFoundException } from '@nestjs/common'
import { InjectRepository } from '@nestjs/typeorm'
import { Repository } from 'typeorm'
import { Assignment } from './assignment.entity'

@Injectable()
export class AssignmentService {
  constructor(
    @InjectRepository(Assignment)
    private readonly assignmentRepository: Repository<Assignment>,
  ) { }

  // 创建新的作业
  async createAssignment(data: Partial<Assignment>): Promise<Assignment> {
    const assignment = this.assignmentRepository.create(data)
    return this.assignmentRepository.save(assignment)
  }

  // 获取所有作业
  async getAllAssignments(): Promise<Assignment[]> {
    return this.assignmentRepository.find()
  }

  // 根据 ID 更新作业
  async updateAssignment(
    id: number,
    data: Partial<Assignment>,
  ): Promise<Assignment> {
    // 查找作业
    const assignment = await this.assignmentRepository.findOne({ where: { id } })

    // 如果作业不存在，抛出异常
    if (!assignment) {
      throw new NotFoundException('作业未找到')
    }

    // 更新作业数据
    Object.assign(assignment, data)

    // 保存更新后的作业
    return this.assignmentRepository.save(assignment)
  }
}
