import { Module } from '@nestjs/common'
import { TypeOrmModule } from '@nestjs/typeorm'
import { UserAssignmentRecord } from '../compiler/user-assignment-record.entity'
import { AssignmentController } from './assignment.controller'
import { Assignment } from './assignment.entity'
import { AssignmentService } from './assignment.service'

@Module({
  imports: [TypeOrmModule.forFeature([Assignment, UserAssignmentRecord])],
  controllers: [AssignmentController],
  providers: [AssignmentService],
  exports: [AssignmentService],
})
export class AssignmentModule {}
