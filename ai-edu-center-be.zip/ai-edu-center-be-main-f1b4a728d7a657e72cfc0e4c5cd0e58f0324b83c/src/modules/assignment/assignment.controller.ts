import { Body, Controller, Get, Param, Patch, Post } from '@nestjs/common'
import { Assignment } from './assignment.entity'
import { AssignmentService } from './assignment.service'

@Controller('assignments')
export class AssignmentController {
  constructor(private readonly assignmentService: AssignmentService) {}

  // 教师创建新的作业
  @Post()
  async createAssignment(@Body() data: Partial<Assignment>): Promise<Assignment> {
    return this.assignmentService.createAssignment(data)
  }

  // 获取所有作业列表
  @Get()
  async getAllAssignments(): Promise<Assignment[]> {
    return this.assignmentService.getAllAssignments()
  }

  // 修改已发布的作业
  @Patch(':id')
  async updateAssignment(
      @Param('id') id: number, // 从路径参数获取作业ID
      @Body() data: Partial<Assignment>, // 请求体中包含修改的数据
  ): Promise<Assignment> {
    return this.assignmentService.updateAssignment(id, data)
  }
}
