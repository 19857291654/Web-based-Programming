import { Column, Entity, PrimaryGeneratedColumn } from 'typeorm'
// import { UserAssignmentRecord } from '../compiler/user-assignment-record.entity'; // 引入关联的实体

@Entity('assignments')
export class Assignment {
  @PrimaryGeneratedColumn()
  id: number // 自增主键

  @Column({ name: 'description', type: 'text' })
  description: string // 作业描述内容

  @Column({ name: 'knowledge_point_id', type: 'varchar', length: 255 })
  knowledgePointId: string // 知识点id

  @Column({ name: 'editor_content', type: 'json', nullable: true }) // 使用 JSON 类型存储 Editor.js 内容
  editorContent: any // 这里用 `any`，因为 JSON 可能是对象

  @Column({ name: 'input_output', type: 'json', nullable: true }) // 使用 JSON 类型存储 Editor.js 内容
  inputOutput: any // 这里用 `any`，因为 JSON 可能是对象

  // 建立与 user_assignment_records 的一对多关系
  // @OneToMany(() => UserAssignmentRecord, (record) => record.assignment)
  // records: UserAssignmentRecord[]; // 提交记录的集合
}
