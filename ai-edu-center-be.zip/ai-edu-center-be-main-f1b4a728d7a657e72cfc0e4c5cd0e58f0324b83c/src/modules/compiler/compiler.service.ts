import { exec } from 'node:child_process'
import * as fs from 'node:fs/promises' // 使用异步文件操作
import path from 'node:path'
import { promisify } from 'node:util'
import { InjectQueue } from '@nestjs/bull'
import { Injectable } from '@nestjs/common'
import { InjectRepository } from '@nestjs/typeorm'
import { Job, Queue } from 'bull'
import stringSimilarity from 'string-similarity' // 使用 string-similarity 库
import { Repository } from 'typeorm'
import { Assignment } from '../assignment/assignment.entity'
import { COMPILER_TASK_QUEUE_NAME } from './constant'
import * as errorTranslations from './errors.json'
import { UserAssignmentRecord } from './user-assignment-record.entity'

const execPromise = promisify(exec)

@Injectable()
export class CompilerService {
  constructor(
    @InjectQueue(COMPILER_TASK_QUEUE_NAME) private readonly compileQueue: Queue,
    @InjectRepository(UserAssignmentRecord)
    private readonly userAssignmentRecordRepository: Repository<UserAssignmentRecord>, // 注入正确的 Repository
    @InjectRepository(Assignment)
    private readonly assignmentRepository: Repository<Assignment>,

  ) { }

  // 3. 创建任务（Job）并添加到队列
  async addToQueue(language: string, code: string, inputValue: string): Promise<Job> {
    try {
      const job = await this.compileQueue.add({ language, service: code, args: inputValue, id: 1 })
      console.log('Job added to queue:', job.id)
      return job
    }
    catch (error) {
      console.error('Error adding job to queue:', error)
      throw new Error('Failed to add job to queue')
    }
  }

  // 去精简报错信息的方法
  private cleanCompileOutput(output: string): string {
    return output
      .split('\n') // 按行分割
      .filter(line => /error:/.test(line)) // 仅保留包含 "error:" 的行
      .map((line) => {
        const match = line.match(/error:\s*(.*)/) // 匹配 "error:" 后面的具体内容
        return match ? match[1].trim() : '' // 提取匹配到的错误内容并去掉首尾空格
      })
      .filter(line => line) // 过滤掉空行
      .join('\n') // 重新合并为字符串
  }

  // 翻译
  private translateError(error: string): string {
    // 直接尝试精确翻译
    for (const [english, chinese] of Object.entries(errorTranslations)) {
      if (error.includes(english)) {
        return chinese // 直接返回中文翻译
      }
    }
    // 处理括号缺失相关的报错
    if (error.includes('expected \')\')') || error.includes('expected \'(\'')) {
      return '缺少右括号或左括号，检查代码中的括号配对是否正确'
    }
    // 使用模糊匹配进行翻译
    const englishErrors = Object.keys(errorTranslations)
    const bestMatch = stringSimilarity.findBestMatch(error, englishErrors)

    if (bestMatch.bestMatch.rating > 0.5) {
      // 相似度足够高，返回最接近的中文翻译
      const closestError = bestMatch.bestMatch.target
      return errorTranslations[closestError]
    }

    // 兜底逻辑：未匹配的错误提供通用提示
    return `未识别的错误信息：系统无法翻译此错误 (${error})，请参考相关文档或联系技术支持。`
  }

  // 通用的编译和运行逻辑
  async compileAndRun(filePath: string, outputExePath: string, compileCommand: string, runCommand: string) {
    let compileOutput = ''
    let runOutput = ''

    try {
      const result = await execPromise(compileCommand, { timeout: 100000 })
      compileOutput = result.stdout || result.stderr || ''
    }
    catch (err) {
      compileOutput = err.stdout || err.stderr || 'Unknown error during compilation'
      runOutput = this.cleanCompileOutput(compileOutput) // 清理输出
      return { compileOutput, runOutput } // 返回清理后的结果
    }

    if (compileOutput.includes('error')) {
      runOutput = this.cleanCompileOutput(compileOutput) // 绑定清理后的结果到 runOutput
      return { compileOutput, runOutput }
    }

    try {
      const result = await execPromise(runCommand, { timeout: 60000 })
      runOutput = result.stdout || result.stderr || ''
    }
    catch (err) {
      runOutput = err.stdout || err.stderr || 'Unknown error during execution'
    }

    return { compileOutput, runOutput }
  }

  // C/C++编译和运行
  async compileAndRunC(code: string, inputValue: string): Promise<{ compileOutput: string, runOutput: string }> {
    const filename = 'temp_code.cpp'
    const outputExe = 'temp_program.exe'
    const filePath = path.join(__dirname, filename)
    const outputExePath = path.join(__dirname, outputExe)

    const modifiedCode = this.insertInputValuesC(code, inputValue)
    await fs.writeFile(filePath, modifiedCode)

    const compileCommand = `g++ "${filePath}" -o "${outputExePath}"`
    const runCommand = `"${outputExePath}"`

    const result = await this.compileAndRun(filePath, outputExePath, compileCommand, runCommand)

    // 清理临时文件
    await fs.unlink(filePath)
    await fs.unlink(outputExePath).catch(() => { }) // 避免在编译失败时出错

    return result
  }

  // Python编译和运行
  async compileAndRunPython(code: string, inputValue: string): Promise<{ compileOutput: string, runOutput: string }> {
    const tempFilePath = path.join(__dirname, 'temp_code.py')
    const modifiedCode = this.insertInputValuesPython(code, inputValue)
    await fs.writeFile(tempFilePath, modifiedCode)

    const runCommand = `python "${tempFilePath}"`
    const result = await this.compileAndRun(tempFilePath, '', '', runCommand)

    await fs.unlink(tempFilePath)

    return result
  }

  // 修改后的 insertInputValuesC 方法，处理多行输入
  insertInputValuesC(code: string, inputValue: string): string {
    const inputLines = inputValue.split(/\s+/) // 按空格和回车拆分成数组

    // 处理 scanf
    code = code.replace(
      /scanf\s*\(\s*"([^"]+)",\s*&([^;]+)\);/g,
      (match, format, variableNames) => {
        const variables = variableNames.split(/\s*,\s*&/).map(v => v.trim()) // 拆分多个变量
        const values = variables.map((variable, index) => {
          let value
          if (format.includes('%d')) {
            value = Number.parseInt(inputLines.shift() || '0', 10) // 整数
          }
          else if (format.includes('%f')) {
            value = Number.parseFloat(inputLines.shift() || '0') // 浮点数
          }
          else if (format.includes('%c')) {
            value = `'${inputLines.shift() || ''}'` // 字符
          }
          else if (format.includes('%s')) {
            value = `"${inputLines.shift() || ''}"` // 字符串
          }
          else {
            value = inputLines.shift() || '' // 默认值
          }
          return `${variable} = ${value}`
        })
        return `${values.join('; ')};` // 返回替换后的语句
      },
    )

    // 处理 cin
    code = code.replace(
      /cin\s*>>\s*([^;]+);/g,
      (match, variableNames) => {
        const variables = variableNames.split(/\s*>>\s*/).map(v => v.trim()) // 拆分多个变量
        const values = variables.map((variable) => {
          const value = inputLines.shift() || '' // 默认插入的值是 inputValue
          return `${variable} = ${value}`
        })
        return `${values.join('; ')};` // 返回替换后的语句
      },
    )

    // 确保 main 函数返回 0
    code = code.replace(/return\s*;/g, 'return 0;')

    return code
  }

  // 插入输入值
  insertInputValuesPython(code: string, inputValue: string): string {
    // 匹配带参数的 input，例如 input("Enter a number: ")
    return code.replace(/input\([^)]*\)/g, `"${inputValue}"`)
  }

  async updateTaskCompleteStatus(tid: number): Promise<void> {
    console.log(2222, tid)
  }

  async saveCompilationRecord(knowledgePointId: string, language: string, userId: string, code: string) {
    const record = new UserAssignmentRecord()
    record.userId = userId
    record.code = code
    record.language = language
    record.knowledgePointId = knowledgePointId
    // 保存到数据库
    return await this.userAssignmentRecordRepository.save(record)
  }

  // 获取所有 user_assignment_records 数据
  async getAllUserAssignmentRecords(): Promise<UserAssignmentRecord[]> {
    return this.userAssignmentRecordRepository.find() // 使用 TypeORM 的 find 方法获取所有记录
  }

  // 根据 knowledgePointId 获取指定作业的所有提交记录
  async getRecordsByKnowledgePointId(knowledgePointId: string): Promise<UserAssignmentRecord[]> {
    return this.userAssignmentRecordRepository.find({
      where: { knowledgePointId }, // 通过 knowledgePointId 查询
    })
  }

  // 根据 userId 获取指定学生的所有提交记录
  async getRecordsByUserId(userId: string): Promise<UserAssignmentRecord[]> {
    return this.userAssignmentRecordRepository.find({
      where: { userId }, // 通过 userId 查询
    })
  }

  // 根据 userId 获取指定学生的作业数据getTaskDataByUserId
  // 根据 id 获取指定作业数据
  async getTaskDataByUserId(id: number): Promise<Assignment> {
    return this.assignmentRepository.findOne({
      where: { id }, // 通过 id 查询
    })
  }
}
