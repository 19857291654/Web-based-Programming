import { Body, Controller, Get, Post } from '@nestjs/common'
import { Public } from '../auth/decorators/public.decorator'
import { CompilerService } from './compiler.service'

@Controller('compile')
export class CompilerController {
  constructor(private readonly compilerService: CompilerService) { }

  @Public()
  @Post()
  async compileCodeByQueue(@Body() body: { knowledgePointId: string, userId: string, language: string, code: string, inputValue: string }) {
    const { knowledgePointId, userId, language, code, inputValue } = body

    try {
      // 保存记录到数据库
      const knowledgePointIdToSave = knowledgePointId || null
      await this.compilerService.saveCompilationRecord(knowledgePointIdToSave, language, userId, code)

      // 将任务添加到队列并等待完成
      const job = await this.compilerService.addToQueue(language, code, inputValue)
      const result = await job.finished() // 等待任务完成并获取结果

      return {
        compileOutput: result.compileOutput || 'No output from compiler',
        runOutput: result.runOutput || 'No output from runner',
      }
    }
    catch (error) {
      console.error('Error while compiling code:', error)
      return {
        message: 'Error while processing the task',
        error: error.message || 'Unknown error',
      }
    }
  }

  @Get('records') // 新接口：获取所有记录
  async getAllUserAssignmentRecords() {
    try {
      const records = await this.compilerService.getAllUserAssignmentRecords() // 调用服务方法获取所有记录
      return {
        message: 'Successfully fetched records',
        data: records,
      }
    }
    catch (error) {
      console.error('Error while fetching records:', error)
      return {
        message: 'Error while fetching records',
        error: error.message || 'Unknown error',
      }
    }
  }

  @Post('records-by-knowledge-point') // 新接口：根据 knowledgePointId 获取指定作业的所有提交记录
  async getRecordsByKnowledgePointId(@Body() body: { knowledgePointId: string }) {
    const { knowledgePointId } = body

    try {
      const records = await this.compilerService.getRecordsByKnowledgePointId(knowledgePointId)

      // 返回查询到的记录
      return {
        message: 'Successfully fetched records for knowledge point',
        data: records,
      }
    }
    catch (error) {
      console.error('Error while fetching records:', error)
      return {
        message: 'Error while fetching records',
        error: error.message || 'Unknown error',
      }
    }
  }

  @Post('records-by-user') // 新接口：根据 userId 获取指定学生的所有提交记录
  async getRecordsByUserId(@Body() body: { userId: string }) {
    const { userId } = body

    try {
      const records = await this.compilerService.getRecordsByUserId(userId)

      // 返回查询到的记录
      return {
        message: 'Successfully fetched records for user',
        data: records,
      }
    }
    catch (error) {
      console.error('Error while fetching records:', error)
      return {
        message: 'Error while fetching records',
        error: error.message || 'Unknown error',
      }
    }
  }

  @Post('run-and-compare') // 新接口：根据 userId 获取指定学生的所有提交记录
  async runAndCompare(@Body() body: { id: number, code: string, language: string }) {
    const { id, language, code } = body
    try {
      const inputValue = await this.compilerService.getTaskDataByUserId(id)

      for (const io of inputValue.inputOutput) {
        const inputString = io.input.join(' ')
        const expectedOutputString = io.output.join(' ')

        try {
          // 将任务添加到队列并等待完成
          const job = await this.compilerService.addToQueue(language, code, inputString)
          const result = await job.finished() // 等待任务完成并获取结果

          const actualOutputString = result.runOutput.trim()

          if (actualOutputString !== expectedOutputString) {
            return {
              message: '预定的输入和对应的输出不匹配',
              error: '预定的输入和对应的输出不匹配',
            }
          }
        }
        catch (error) {
          console.error('代码编译队列添加错误:', error)
          return {
            message: '代码编译队列添加错误',
            error: error.message || 'Unknown error',
          }
        }
      }
      return {
        message: '预定的输入和对应的输出匹配',
      }
    }
    catch (error) {
      return {
        message: '接口获取作业数据失败',
        error: error.message || 'Unknown error',
      }
    }
  }
}
