import { BullModule } from '@nestjs/bull'

import { Module } from '@nestjs/common'
import { ConfigService } from '@nestjs/config'
import { TypeOrmModule } from '@nestjs/typeorm'
import { ConfigKeyPaths, IRedisConfig } from '~/config'
import { Assignment } from '../assignment/assignment.entity'
import { UserAssignmentRecord } from '../compiler/user-assignment-record.entity'
import { CompilerController } from './compiler.controller'
import { CompilerProcessor } from './compiler.processor'
import { CompilerService } from './compiler.service'
import { COMPILER_TASK_QUEUE_NAME, COMPILER_TASK_QUEUE_PREFIX } from './constant'
// 2.配置 BullModule，提供队列的注册
const providers = [CompilerService, CompilerProcessor]
@Module({
  controllers: [CompilerController],
  providers: [...providers],
  imports: [
    BullModule.registerQueueAsync({ // 2222222222.配置 BullModule，提供队列的注册
      name: COMPILER_TASK_QUEUE_NAME,
      useFactory: (configService: ConfigService<ConfigKeyPaths>) => ({ // useFactory 是一个工厂函数，用于在运行时动态创建队列的配置。这个工厂函数将返回一个包含队列配置的对象。
        redis: configService.get<IRedisConfig>('redis'), // 从 ConfigService 获取 redis 配置，通常这会从环境变量或配置文件中读取 Redis 连接的相关设置（如主机、端口、密码等）
        prefix: COMPILER_TASK_QUEUE_PREFIX, // 设置队列的前缀。使用前缀可以帮助区分不同类型的队列，避免在 Redis 中发生键名冲突。
      }),
      inject: [ConfigService],
    }),
    TypeOrmModule.forFeature([UserAssignmentRecord, Assignment]), // 注册实体
  ],
})
export class CompilerModule {}
