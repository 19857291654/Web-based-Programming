export enum TaskStatus { // TaskStatus 枚举表示任务的状态。
  Disabled = 0, // Disabled = 0：任务禁用状态。
  Activited = 1, // Activited = 1：任务激活状态。
}

export enum TaskType { // TaskType 枚举表示任务的类型。
  Cron = 0, // Cron = 0：表示定时任务（cron 类型任务）。
  Interval = 1, // Interval = 1：表示间隔任务（每隔固定时间重复执行的任务）。
}

export const COMPILER_TASK_QUEUE_NAME = 'compiler-task' // 编译 任务 队列 名称

export const COMPILER_TASK_QUEUE_PREFIX = 'compiler:task' // 编译 任务 队列 前缀
