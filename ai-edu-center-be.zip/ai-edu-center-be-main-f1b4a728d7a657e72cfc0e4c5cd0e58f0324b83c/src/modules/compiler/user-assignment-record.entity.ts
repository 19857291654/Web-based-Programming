import { Column, Entity, PrimaryGeneratedColumn } from 'typeorm'

@Entity('user_assignment_records')
export class UserAssignmentRecord {
  @PrimaryGeneratedColumn('uuid', { name: 'record_id' })
  recordId: string // 自增主键

  @Column({ name: 'user_id' })
  userId: string // 用户ID

  @Column({ name: 'knowledge_point_id', nullable: true })
  knowledgePointId: string // 知识点 ID，可为空

  @Column({ name: 'code', type: 'text' })
  code: string // 提交的代码

  @Column({ name: 'language', type: 'text' })
  language: string // 提交的代码

  @Column({ name: 'created_at', type: 'timestamp', default: () => 'CURRENT_TIMESTAMP' })
  createdAt: Date // 记录创建时间

  @Column({ name: 'updated_at', type: 'timestamp', default: () => 'CURRENT_TIMESTAMP', onUpdate: 'CURRENT_TIMESTAMP' })
  updatedAt: Date // 记录最后更新时间
}
