import { OnQueueCompleted, Process, Processor } from '@nestjs/bull'
import { Job } from 'bull'
import { CompilerService } from './compiler.service'
import { COMPILER_TASK_QUEUE_NAME } from './constant'

export interface ExecuteData {
  language: string
  id: number
  args?: string | null
  service: string
}

@Processor(COMPILER_TASK_QUEUE_NAME)
export class CompilerProcessor {
  constructor(private compilerService: CompilerService) { }

  // 处理队列中的任务
  @Process()
  async handle(job: Job<ExecuteData>) {
    const { language, service, args } = job.data
    let compileOutput = ''
    let runOutput = ''

    try {
      if (language === 'C' || language === 'C++') {
        const result = await this.compilerService.compileAndRunC(service, args)

        compileOutput = result.compileOutput
        runOutput = result.runOutput
      }
      else if (language === 'Python3') {
        const result = await this.compilerService.compileAndRunPython(service, args)
        compileOutput = result.compileOutput
        runOutput = result.runOutput
      }
    }
    catch (error) {
      console.error('Compilation or execution error:', error)
      compileOutput = 'Compilation or execution failed'
      runOutput = error.message || 'Unknown error'
    }
    return { compileOutput, runOutput }
  }

  @OnQueueCompleted()
  onCompleted(job: Job<ExecuteData>) {
    this.compilerService.updateTaskCompleteStatus(job.data.id)
    console.log('任务完成', job.data.id)
  }
}
