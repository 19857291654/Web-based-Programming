// 此文件用于声明 typescript 尚未支持的 ES 提案中的新特性的类型
