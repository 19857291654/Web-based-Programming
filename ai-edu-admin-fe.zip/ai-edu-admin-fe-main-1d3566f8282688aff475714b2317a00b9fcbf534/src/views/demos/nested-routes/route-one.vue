<template>
  <div>
    <div>路由一</div>
    <a-input />
  </div>
</template>

<script lang="ts" setup>
  defineOptions({
    name: 'DemosNestedRoutesOne',
  });
</script>
