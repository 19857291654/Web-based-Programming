<template>
  <div>
    <div>路由二</div>
    <a-input />
  </div>
</template>

<script lang="ts" setup>
  defineOptions({
    name: 'DemosNestedRoutesTwo',
  });
</script>
