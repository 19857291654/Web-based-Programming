<template>
  <div>
    <div>路由三</div>
    <a-input />
  </div>
</template>

<script lang="ts" setup>
  defineOptions({
    name: 'DemosNestedRoutesThree',
  });
</script>
