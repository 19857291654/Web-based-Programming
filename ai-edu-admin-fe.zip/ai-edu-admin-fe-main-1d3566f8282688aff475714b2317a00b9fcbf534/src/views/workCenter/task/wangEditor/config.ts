export const initHtml = `<p style="text-align: left;">这是一个编程题模板。</p>
    <h3 style="text-align: left;">题目描述:</h3>
    <p style="text-align: left;">请在这里写题目描述。例如:本题目要求读入2个整数A和B,然后输出它们的和。</p>
    <h3 style="text-align: left;">输入格式:</h3>
    <p style="text-align: left;">请在这里写输入格式。例如:输入在一行中给出2个绝对值不超过1000的整数A和B。</p>
    <h3 style="text-align: left;">输出格式:</h3>
    <p style="text-align: left;">请在这里描述输出格式。例如:对每一组输入,在一行中输出A+B的值。</p>
    <h3 style="text-align: left;">输入样例:</h3>
    <p style="text-align: left;">在这里给出一组输入。例如：</p>
    <pre style="text-align: left;"><code class="language-in">18 -299</code></pre>
    <h3 style="text-align: left;">输出样例:</h3>
    <p style="text-align: left;">在这里给出相应的输出。例如：</p>
    <pre style="text-align: left;"><code class="language-out">-281</code></pre>`;
