<template>
  <div style="border: 1px solid #ccc">
    <div v-if="!view">
      <Toolbar
        style="border-bottom: 1px solid #ccc"
        :editor="editorRef"
        :defaultConfig="toolbarConfig"
        :mode="mode"
      />
    </div>
    <Editor
      v-model="valueHtml"
      aria-hidden="false"
      style="height: 450px; overflow: auto"
      :defaultConfig="editorConfig"
      :mode="mode"
      @onCreated="handleCreated"
    />
  </div>
</template>

<script setup>
  import '@wangeditor/editor/dist/css/style.css'; // 引入 css

  import { onBeforeUnmount, ref, shallowRef, onMounted, defineEmits, defineExpose } from 'vue';
  import { Editor, Toolbar } from '@wangeditor/editor-for-vue';
  import { initHtml } from './config';

  const props = defineProps(['view', 'edit', 'task']);
  const emit = defineEmits(['value-updated']); // 定义 value-updated 事件

  const editorRef = shallowRef();

  // 内容 HTML
  const valueHtml = ref(initHtml);
  const mode = 'simple';
  // 模拟 ajax 异步获取内容
  onMounted(() => {});

  const toolbarConfig = {};
  const editorConfig = { placeholder: '请输入内容', autoFocus: true };

  // 组件销毁时，也及时销毁编辑器
  onBeforeUnmount(() => {
    const editor = editorRef.value;
    if (editor == null) return;
    editor.destroy();
  });

  const handleCreated = (editor) => {
    editorRef.value = editor; // 记录 editor 实例，重要！
    initContent();
    setTimeout(() => {
      if (props.view) {
        toolbarDisabled();
      }
    }, 100);
  };
  const initContent = () => {
    const editor = editorRef.value;
    if (props.view || props.edit) {
      valueHtml.value = props.task.editorContent;
    } else {
      valueHtml.value = initHtml;
    }
  };

  const toolbarDisabled = () => {
    const editor = editorRef.value;
    editor.disable();
  };

  const getChildValue = () => {
    const editor = editorRef.value;

    return editor.getHtml();
  };

  defineExpose({
    // 将 getChildValue 方法暴露给父组件
    getChildValue,
  });
</script>
