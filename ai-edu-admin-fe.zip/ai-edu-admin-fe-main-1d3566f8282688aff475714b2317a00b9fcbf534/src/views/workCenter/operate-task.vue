<template>
  <div>
    <!-- Top Section -->
    <Card>
      <div class="header">
        <div class="add">
          <AButton type="primary" @click="addTask">添加作业</AButton>
        </div>

        <div class="filterr">
          <!-- Vertical Text for '全部' -->
          <span>all</span>
          <input
            id="all"
            v-model="selectedFilter"
            type="radio"
            value="全部"
            @change="loadAllTasks"
          />
          <span />
          <a-input v-model:value.lazy="knowledgePointId" placeholder="筛选:输入知识点ID" />
          <span />
          <AButton type="primary" @click="searchTasks">作业搜索</AButton>
          <span />
        </div>
      </div>

      <!-- Task List Section -->
      <Divider orientation="left">作业展示</Divider>
      <div v-if="tasks.length > 0" class="tasks-list">
        <div v-for="(task, index) in filteredTasks" :key="index" class="task-item">
          <div class="details">
            <div class="task-icon pending" />
            <div class="task-details">
              <div class="task-name">作业{{ task.id }}</div>
            </div>
          </div>

          <div class="dialage">
            <AButton type="primary" @click="showTaskDetails(task)">作业详情</AButton>
          </div>
        </div>
      </div>

      <div v-else>
        <img src="@/assets/images/no-task.png" alt="" />
      </div>
      <!-- Drawer for Task Details -->
      <taskDrawer
        v-if="taskDrawerVisible"
        v-model:open="taskDrawerVisible"
        :task="selectedTask"
        v-on:update:open="taskDrawerVisible = $event"
        @taskUpdated="getTasks"
      >
        <template #default="{}">
          <p>题目要求:</p>
          <wangEditor :task="selectedTask" :view="view" />
        </template>
      </taskDrawer>

      <a-modal
        v-if="addTaskVisible"
        v-model:open="addTaskVisible"
        title="添加作业"
        :style="{ height: 'calc(100vh - 50px)', top: '50px' }"
        width="70%"
        @ok="saveForm"
      >
        <a-form
          :model="newTaskForm"
          :rules="rules"
          :label-col="{ span: 4 }"
          :wrapper-col="{ span: 18 }"
        >
          <a-form-item label="知识点ID" name="knowledgePointId">
            <a-input
              v-model:value="newTaskForm.knowledgePointId"
              placeholder="请输入知识点ID"
              allow-clear
            />
          </a-form-item>

          <a-form-item label="输入数据" name="inputData">
            <a-input
              v-model:value="newTaskForm.inputData"
              placeholder="这里输入输入的测试数据"
              allow-clear
            />
          </a-form-item>
          <a-form-item label="输出数据" name="outputData">
            <a-input
              v-model:value="newTaskForm.outputData"
              placeholder="这里输入输出的测试数据"
              allow-clear
            />
          </a-form-item>

          <a-form-item label="题目描述" name="description">
            <wangEditor ref="wangEditorHtml" :add="add" />
          </a-form-item>
        </a-form>
      </a-modal>
    </Card>
  </div>
</template>

<script setup lang="ts">
  import { ref, watch, type Ref, onMounted } from 'vue';

  import { Card, Divider, message } from 'ant-design-vue';
  import type { Rule } from 'ant-design-vue/es/form';
  import taskDrawer from '@/components/teaher/taskDrawer.vue';
  import { getAssignments, addAssignments } from '@/api/teacher/assignments';
  import { AButton } from '@/components/basic/button';

  import wangEditor from '@/views/workCenter/task/wangEditor/index.vue';
  // 假设 wangEditor 组件的类型（你需要根据实际情况调整类型）
  type WangEditorInstance = {
    getChildValue: () => string; // 假设该方法返回一个字符串
  };

  const wangEditorHtml: Ref<WangEditorInstance | null> = ref(null);

  interface Task {
    knowledgePointId: string;
    description: string;
    id: number;
  }
  const selectedFilter = ref('全部'); // 默认选中全部
  const knowledgePointId = ref('');
  const add = ref(true);
  const view = ref(true);
  const tasks = ref<Task[]>([]); // 显式指定类型
  const filteredTasks = ref<Task[]>([]); // 显式指定类型
  const taskDrawerVisible = ref(false);
  const addTaskVisible = ref(false);
  const selectedTask = ref({ editorContent: [] });
  const newTaskForm = ref({
    knowledgePointId: '',
    description: '',
    inputData: '',
    outputData: '',
  });

  const rules: Record<string, Rule[]> = {
    knowledgePointId: [
      {
        required: true,
        message: '请输入知识点ID',
        // trigger: 'blur',
        type: 'string', // 显式指定类型
      },
    ],
    description: [
      {
        required: true,
        message: '请输入作业任务',
        // trigger: 'change',
        type: 'string', // 显式指定类型
      },
    ],
    input: [
      {
        type: 'string', // 显式指定类型
      },
    ],
    output: [
      {
        type: 'string', // 显式指定类型
      },
    ],
  };

  // 当 taskDrawerVisible 变为 true 时，等待 DOM 更新后初始化 Editor.js
  watch(addTaskVisible, async (visible) => {});

  watch(taskDrawerVisible, async (visible) => {});

  // 添加作业
  const addTask = () => {
    addTaskVisible.value = true;
  };

  // 当点击 "全部" radio 按钮时，加载所有任务
  const loadAllTasks = () => {
    if (selectedFilter.value === '全部') {
      filteredTasks.value = tasks.value;
    }
  };

  // 搜索作业
  const searchTasks = () => {
    if (knowledgePointId.value) {
      filteredTasks.value = tasks.value.filter(
        (task) => task.knowledgePointId === knowledgePointId.value,
      );
      selectedFilter.value = '';
    } else {
      message.warning('未输入知识点ID');
    }
  };

  // 显示作业详情
  const showTaskDetails = (task: any) => {
    selectedTask.value = task;
    taskDrawerVisible.value = true;
  };

  //获取作业列表
  const getTasks = async () => {
    const res: any = await getAssignments();
    tasks.value = res;
    filteredTasks.value = tasks.value;
  };

  //数据转换
  function transformData() {
    // 去除首尾空格，并按空格分隔为数组
    const inputArray = newTaskForm.value.inputData.trim().split(/\s+/);
    const outputArray = newTaskForm.value.outputData.trim().split(/\s+/);

    // 返回转换后的结构
    return [
      {
        input: inputArray,
        output: outputArray,
      },
    ];
  }

  //发布作业
  const saveForm = async () => {
    if (!wangEditorHtml.value) {
      return;
    }

    const Html = wangEditorHtml.value.getChildValue();
    const knowledgePointId = newTaskForm.value.knowledgePointId.trim();

    if (Html) {
      if (Html === '' || !knowledgePointId) {
        message.info('作业ID或题目描述不能为空');
        return;
      }
    }
    const result = transformData();
    const res = await addAssignments({
      description: newTaskForm.value.description.trim(),
      knowledgePointId: newTaskForm.value.knowledgePointId.trim(),
      editorContent: JSON.stringify(Html),
      inputOutput: JSON.stringify(result),
    });
    if (res) {
      message.success('作业发布成功');
      addTaskVisible.value = false;
      newTaskForm.value = {
        knowledgePointId: '',
        description: '',
        inputData: '',
        outputData: '',
      };
      getTasks();
    } else {
      message.error('作业发布失败');
    }
  };

  onMounted(() => {
    getTasks();
  });
</script>

<style scoped lang="less">
  .header {
    display: flex;
    justify-content: space-between;
    margin-bottom: 16px;

    .filterr {
      display: flex;
      align-items: center;

      span {
        margin-right: 8px;
      }
    }
  }

  .tasks-list {
    max-height: 500px;
    overflow-y: auto;
  }

  .task-item {
    display: flex;
    justify-content: space-between;
    padding: 8px;
    border-bottom: 1px solid #f0f0f0;
  }

  .task-icon.pending {
    width: 24px;
    height: 24px;
    background-color: #f4b400;
  }

  .task-details {
    flex-grow: 1;
    margin-left: 8px;
  }

  .dialage {
    display: flex;
    align-items: center;
  }

  .ant-form {
    height: 600px;
    margin: 0;
    overflow: auto;
  }

  .editor {
    height: 450px;
    overflow: auto;
    background-color: #ccc;
  }

  .taskEditor {
    height: 450px;
    overflow: auto;
    background-color: #ccc;
  }
</style>
