import TabsView from './tabs-view.vue';

export { TabsView };
