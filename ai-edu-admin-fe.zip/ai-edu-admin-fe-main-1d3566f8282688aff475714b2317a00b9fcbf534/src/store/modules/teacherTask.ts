import { defineStore } from 'pinia';

export const useTeacherTaskStore = defineStore('teacherTaskStore', {
  state: () => ({
    editContent: '',
    editContentChsnge: false,
  }),
});
