import 'uno.css';
import 'virtual:svg-icons-register';
import '@/styles/index.less';

// 引入静态资源
export const setupAssets = () => ({});
