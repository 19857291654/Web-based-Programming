export { setupAntd } from '@/plugins/antd';
export { setupAssets } from '@/plugins/assets';
export { setupGlobalMethods } from '@/plugins/globalMethods';
