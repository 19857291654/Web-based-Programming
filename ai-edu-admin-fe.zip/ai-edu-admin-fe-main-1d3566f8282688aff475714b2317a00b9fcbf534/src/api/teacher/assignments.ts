import { request } from '@/utils/request';

// 获取所有作业
export async function getAssignments() {
  return request<any>({
    url: '/api/assignments',
    method: 'GET',
  });
}

// 添加新作业
export async function addAssignments(params: any) {
  return request<any>({
    url: '/api/assignments',
    method: 'POST',
    data: params,
  });
}

// 修改作业
export async function editAssignments(id: number, params: any) {
  return request<any>({
    url: `/api/assignments/${id}`, // 动态传递 ID
    method: 'PATCH',
    data: params,
  });
}
