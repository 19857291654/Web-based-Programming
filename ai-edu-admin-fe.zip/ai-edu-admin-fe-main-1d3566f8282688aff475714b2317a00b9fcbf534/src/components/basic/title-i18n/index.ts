export { default as TitleI18n } from './index.vue';
