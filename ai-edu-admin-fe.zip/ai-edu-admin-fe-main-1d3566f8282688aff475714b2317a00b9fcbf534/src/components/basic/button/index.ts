import AButton from './button.vue';

export default AButton;

export const Button = AButton;

export * from './button';

export { AButton };
