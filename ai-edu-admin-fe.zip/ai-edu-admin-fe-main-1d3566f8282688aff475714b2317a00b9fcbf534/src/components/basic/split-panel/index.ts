import SplitPanel from './index.vue';

export { SplitPanel };
