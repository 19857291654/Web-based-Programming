import TinymceEditor from './index.vue';

export default TinymceEditor;

export { TinymceEditor };
