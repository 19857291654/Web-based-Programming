import LockScreen from './index.vue';

export { LockScreen };
