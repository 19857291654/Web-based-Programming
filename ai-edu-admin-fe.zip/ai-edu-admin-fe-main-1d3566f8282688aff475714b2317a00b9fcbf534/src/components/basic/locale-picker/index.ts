export { default as LocalePicker } from './index.vue';
