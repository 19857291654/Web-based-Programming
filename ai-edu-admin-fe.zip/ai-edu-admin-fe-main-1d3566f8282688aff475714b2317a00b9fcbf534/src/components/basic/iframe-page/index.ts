import IFramePage from './index.vue';

export default IFramePage;
