<template>
  <a-drawer :width="500" placement="right" :open="open" @close="onClose">
    <template #title> 作业{{ task.id }} </template>
    <template #extra>
      <a-button type="primary" @click="onClose">close</a-button>
    </template>

    <div class="content">
      <div>
        <hr />
        <div class="introduce">
          <!-- <div class="info">
            <p>知识点</p>
            <p>数组</p>
          </div> -->
          <div class="info">
            <p>难度</p>
            <p>简单</p>
          </div>
          <div class="info">
            <p>作业ID</p>
            <p>{{ task.knowledgePointId }}</p>
          </div>
        </div>
        <hr />
        <p>
          <AButton type="primary" @click="taskStreamVisible = !taskStreamVisible"
            >输入和输出显示</AButton
          >
        </p>

        <slot :task="task" />
        <!-- 插槽，用于显示传递的数据 -->
      </div>
    </div>

    <template #footer>
      <div style="flex: auto">
        <a-button type="primary" @click="changeTask">修改此题</a-button>
      </div>
      <!-- 遮罩层及表单的模态框 -->
      <a-modal
        v-if="taskEditDrawerVisible"
        v-model:open="taskEditDrawerVisible"
        title="修改作业"
        :style="{ height: 'calc(100vh - 50px)', top: '50px' }"
        width="70%"
        @ok="saveChange"
      >
        <a-form
          :model="newTaskForm"
          :rules="rules"
          :label-col="{ span: 4 }"
          :wrapper-col="{ span: 18 }"
        >
          <a-form-item label="知识点ID" name="knowledgePointId">
            <!-- Use v-model:value instead of v-model:value.lazy -->
            <a-input
              v-model:value.lazy="newTaskForm.knowledgePointId"
              placeholder="请输入知识点ID"
              allow-clear
            />
          </a-form-item>

          <a-form-item label="输入数据" name="inputData">
            <a-input
              v-model:value="newTaskForm.inputData"
              placeholder="这里输入输入的测试数据"
              allow-clear
            />
          </a-form-item>
          <a-form-item label="输出数据" name="outputData">
            <a-input
              v-model:value="newTaskForm.outputData"
              placeholder="这里输入输出的测试数据"
              allow-clear
            />
          </a-form-item>

          <a-form-item label="题目描述" name="description">
            <!-- Use v-model:value instead of v-model:value.lazy -->
            <wangEditor ref="wangEditorHtml" :edit="edit" :task="task" />
          </a-form-item>
        </a-form>
      </a-modal>

      <a-modal
        v-model:open="taskStreamVisible"
        title="Basic Modal"
        @ok="taskStreamVisible = !taskStreamVisible"
      >
        <p>{{ task.inputOutput }}</p>
      </a-modal>
    </template>
  </a-drawer>
</template>
<script lang="ts" setup>
  import { defineProps, defineEmits, ref, type Ref } from 'vue';
  import { Modal, message } from 'ant-design-vue';
  import type { Rule } from 'ant-design-vue/es/form';
  import { editAssignments } from '@/api/teacher/assignments';
  import wangEditor from '@/views/workCenter/task/wangEditor/index.vue';
  import { AButton } from '@/components/basic/button';

  type WangEditorInstance = {
    getChildValue: () => string; // 假设该方法返回一个字符串
  };

  const wangEditorHtml: Ref<WangEditorInstance | null> = ref(null);

  const props = defineProps({
    task: {
      type: Object,
      default: () => ({}),
    },
    open: {
      type: Boolean,
      default: false,
    },
  });

  const taskEditDrawerVisible = ref(false); // 控制抽屉或模态框显示
  const taskStreamVisible = ref(false);
  const edit = ref(true); // 控制编辑器是否可编辑

  const newTaskForm = ref({
    knowledgePointId: '',
    description: '',
    inputData: '',
    outputData: '',
  });
  const oddTaskForm = ref({
    knowledgePointId: '',
    description: '',
    inputData: '',
    outputData: '',
  });
  const rules: Record<string, Rule[]> = {
    knowledgePointId: [
      {
        required: true,
        message: '请输入知识点ID',
        // trigger: 'change',
        type: 'string', // 显式指定类型
      },
    ],
    description: [
      {
        required: true,
        message: '请输入作业任务',
        // trigger: 'change',
        type: 'string', // 显式指定类型
      },
    ],
    input: [
      {
        type: 'string', // 显式指定类型
      },
    ],
    output: [
      {
        type: 'string', // 显式指定类型
      },
    ],
  };

  const emit = defineEmits(['update:open', 'taskUpdated']);
  const onClose = () => {
    emit('update:open', false);
  };

  //数据提取
  function revertTransformData() {
    if (props.task.inputOutput) {
      const inputArray = props.task.inputOutput[0].input;
      const inputData = inputArray.join(' ').trim();
      newTaskForm.value.inputData = inputData;
      oddTaskForm.value.inputData = inputData;
    }
    if (props.task.inputOutput) {
      const outputArray = props.task.inputOutput[0].output;
      const outputData = outputArray.join(' ').trim();
      newTaskForm.value.outputData = outputData;
      oddTaskForm.value.outputData = outputData;
    }
    // return { inputData, outputData };
  }

  //改变作业
  const changeTask = () => {
    revertTransformData();
    if (!props.task) {
      return;
    }
    // 初始化表单内容
    oddTaskForm.value.knowledgePointId = props.task.knowledgePointId || '';
    oddTaskForm.value.description = props.task.description || '';

    newTaskForm.value.knowledgePointId = props.task.knowledgePointId || '';
    newTaskForm.value.description = props.task.description || '';
    taskEditDrawerVisible.value = true; // 打开模态框
    // emit('update:open', false);
  };

  //数据转换
  function transformData() {
    // 去除首尾空格，并按空格分隔为数组
    const inputArray = newTaskForm.value.inputData.trim().split(/\s+/);
    const outputArray = newTaskForm.value.outputData.trim().split(/\s+/);

    // 返回转换后的结构
    return [
      {
        input: inputArray,
        output: outputArray,
      },
    ];
  }

  // 保存修改
  const saveChange = async () => {
    try {
      if (!wangEditorHtml.value) {
        return;
      }

      const Html = wangEditorHtml.value.getChildValue();
      const knowledgePointId = newTaskForm.value.knowledgePointId.trim();

      // const description = newTaskForm.value.description.trim();
      if (Html === '' || !knowledgePointId) {
        message.info('作业ID或题目描述不能为空');
        return;
      } else if (knowledgePointId === oddTaskForm.value.knowledgePointId) {
        message.info('作业任务或知识点ID未修改');
        return;
      } else {
        Modal.confirm({
          title: '确定要修改作业吗?',
          async onOk() {
            const result = transformData();
            const res = await editAssignments(props.task.id, {
              // 这里的2是你想要修改的作业ID
              description: newTaskForm.value.description,
              knowledgePointId: newTaskForm.value.knowledgePointId,
              editorContent: JSON.stringify(Html),
              inputOutput: JSON.stringify(result),
            });
            if (res) {
              message.success('修改成功');
              emit('taskUpdated');
              onClose();
              taskEditDrawerVisible.value = false;
            } else {
              message.error('修改失败');
            }
          },
          onCancel() {},
        });
      }
    } catch (error) {
      console.error('Error saving editor data:', error);
    }
  };
</script>

<style lang="less" scoped>
  .content {
    margin: 20px;
  }

  .introduce {
    display: flex;
    margin-bottom: 20px;
  }

  .info {
    display: flex;
    flex-direction: column;
    align-items: flex-start;
    margin-right: 20px;
  }

  .info p:first-child {
    font-weight: bold;
  }

  .info p:last-child {
    margin-top: 4px;
  }

  .ant-form {
    height: 600px;
    margin: 0 auto;
    overflow: auto;
  }

  .editor {
    // width: 100px;
    height: 450px;
    overflow: auto;
    background-color: #ccc;
  }
</style>
