export { default as DraggableModal } from './index.vue';
