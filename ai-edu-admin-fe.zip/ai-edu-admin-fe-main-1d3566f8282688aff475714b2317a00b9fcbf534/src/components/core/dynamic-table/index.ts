export { default as DynamicTable } from './src/dynamic-table.vue';

export * from './src/types/';
export * from './src/hooks/';
export * from './src/dynamic-table';
