/** 用户token */
export const ACCESS_TOKEN_KEY = 'ACCESS_TOKEN';

/** 国际化 */
export const LOCALE_KEY = 'LOCALE__';

/** 主题色 */
export const THEME_KEY = 'THEME__';

/** 用户信息 */
export const USER_INFO_KEY = 'USER__INFO__';
