import type { RouteRecordRaw } from 'vue-router';
import { t } from '@/hooks/useI18n';

const moduleName = 'workCenter';

const routes: Array<RouteRecordRaw> = [
  {
    path: '/workCenter',
    name: moduleName,
    redirect: { name: `${moduleName}-custom-modal` },
    meta: {
      title: t('routes.workCenter.workCenter'),
      icon: 'ant-design:container-outlined',
    },
    children: [
      {
        path: 'operate-task',
        name: `${moduleName}-custom-modal`,
        meta: {
          title: t('routes.workCenter.operate'),
          icon: 'ant-design:edit-outlined',
          keepAlive: false,
        },
        component: () => import('@/views/workCenter/operate-task.vue'),
      },
    ],
  },
];

export default routes;
