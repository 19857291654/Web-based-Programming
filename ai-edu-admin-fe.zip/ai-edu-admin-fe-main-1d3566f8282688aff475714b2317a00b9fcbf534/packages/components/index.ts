import 'uno.css';

/**
 * 此包供 playground 在线测试使用，不建议在生产环境中使用
 */

export * from '@/components/core/dynamic-table/';
export * from '@/components/core/schema-form/';

console.log('[@admin-pkg/components] load');
